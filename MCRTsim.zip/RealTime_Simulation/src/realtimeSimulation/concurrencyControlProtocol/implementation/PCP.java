/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package realtimeSimulation.concurrencyControlProtocol.implementation;

import java.util.Vector;
import realtimeSimulation.Controller;
import realtimeSimulation.DataSetting;
import realtimeSimulation.Final;
import realtimeSimulation.Job;
import realtimeSimulation.Priority;
import realtimeSimulation.Resource;
import realtimeSimulation.concurrencyControlProtocol.ConcurrencyControlProtocol;
import realtimeSimulation.concurrencyControlProtocol.ConcurrencyControlProtocol;

/**
 *
 * @author ShiuJia
 */
public class PCP extends ConcurrencyControlProtocol
{
    //Vector<Integer> ResourceCeiling;
    
    public PCP(DataSetting ds)
    {
        super(ds);
        this.setName("Priority Ceiling Protocol");
        this.setPIP(true);

        for(int i = 0; i < this.getDataSetting().getTaskSet().size(); i++)
        {
            
        }
        
        for(int i = 0; i < this.getDataSetting().getResourceSet().size(); i++)
        {
            this.getDataSetting().getResourceSet(i).setPriorityCeiling(Final.Ohm);
            for(int j = 0; j < this.getDataSetting().getResourceSet().get(i).getAccessSet().size(); j++)
            {
                if(this.getDataSetting().getResourceSet().get(i).getAccessSet().get(j).isPriorityHigher(this.getDataSetting().getResourceSet(i).getPriorityCeiling()))
                {
                    this.getDataSetting().getResourceSet().get(i).setPriorityCeiling(this.getDataSetting().getResourceSet().get(i).getAccessSet().get(j).getPriority());
                }
            }
        }
    }

    @Override
    public Resource checkLock(Job j, Resource r)
    {
        if(r.whoLocked() == null) //檢查使用資源是否已被Lock：通過
        {
            if(j.isPriorityHigher(this.getSystemCeiling(j))) //檢查與系統Ceiling：通過
            {
                return null;
            }
            else //檢查與系統Ceiling：阻擋
            {
                return this.ResourceOfSystemCeiling(j);
            }
        }
        else //檢查使用資源是否已被Lock：阻擋
        {
            return r;
        }
    }
    
    public Resource ResourceOfSystemCeiling(Job j)
    {
        Priority ceiling = Final.Ohm;
        Resource resource = null;
        for(int i = 0; i < this.getDataSetting().getResourceSet().size(); i++)
        {
            if(this.getDataSetting().getResourceSet().get(i).whoLocked() != null && this.getDataSetting().getResourceSet().get(i).whoLocked() != j)
            {
                if(this.getDataSetting().getResourceSet(i).isPriorityHigher(ceiling))
                {
                    ceiling = this.getDataSetting().getResourceSet().get(i).getPriorityCeiling();
                    resource = this.getDataSetting().getResourceSet().get(i);
                }
            }
        }
        return resource;
    }
    
    public Priority getSystemCeiling(Job j)
    {
        if(this.ResourceOfSystemCeiling(j) == null)
        {
            return Final.Ohm;
        }
        else
        {
            return this.ResourceOfSystemCeiling(j).getPriorityCeiling();
        }
    }
}
