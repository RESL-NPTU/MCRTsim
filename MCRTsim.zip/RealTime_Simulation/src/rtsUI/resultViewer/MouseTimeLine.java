/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rtsUI.resultViewer;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JPanel;


/**
 *
 * @author YC
 */
public class MouseTimeLine extends JPanel {
    public ResultViewer parent;
    Double curTime;
    
    public MouseTimeLine ()
    {
        
       super(); 
    }
    
    public MouseTimeLine (ResultViewer rv, Double x)
    {
        super();
        this.parent = rv;
        this.curTime = x;
        
        this.addMouseListener(new MouseAdapter(){
            public void mouseClicked(MouseEvent e)
            {
                MouseTimeLine.this.parent.getTimeLineSet().removeItem(MouseTimeLine.this.curTime);
                MouseTimeLine.this.parent.remove(MouseTimeLine.this);
                MouseTimeLine.this.parent.getMouseTimeLine().remove(MouseTimeLine.this);
                MouseTimeLine.this.parent.repaint();
            }
        });
    }
    
    public void reSetItself()
    {
        this.setBounds(Double.valueOf(curTime * this.parent.parent.baseunit).intValue()+100-5, 10, 10, 10);
    }
    
    public Double getCurTime()
    {
        return this.curTime;
    }
    
    public int getCurPoint()
    {
        return Double.valueOf(curTime * this.parent.parent.baseunit).intValue()+100;
    }
    
    
    
}
