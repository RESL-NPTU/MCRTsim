/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rtsUI.resultViewer;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.text.DecimalFormat;
import java.util.ArrayList;
import javax.swing.JPanel;
import realtimeSimulation.TaskSet;
import rtsUI.InfoWin;
/**
 *
 * @author ShiuJia
 */
public class TaskTimeLine {
        int resourceHeight=13;
        int taskHeight = 80;
	int ID;
	Point o;
	ScheduleResult parent;
	ArrayList<TaskExecution> executions; 
        ArrayList<Resources> re;
	
	public TaskTimeLine() {
		// TODO Auto-generated constructor stub
	}
	
	public TaskTimeLine(ScheduleResult sr, int i, String id)
	{
                re = new ArrayList<>();
		parent = sr;
		ID = new Integer(id).intValue();
		o = new Point(100,200+i*150);
		executions = new ArrayList<TaskExecution>();
	}
	
        public void addExecution(double s,double e,String sta, int sp)
        {
		executions.add(new TaskExecution(s,e,sta,sp));
	}
        
	public void addExecution(double s,double e, String sta, int sp, ArrayList<String> a)
        {
		executions.add(new TaskExecution(s,e,sta,sp,a));
	}
	
	public void drawItself(Graphics g)
	{
            
		for(int i = -1 ; i<=1 ; i++)
                {
                    g.drawLine(o.x, o.y+i, o.x+parent.baseunit*(parent.finalTime+1), o.y+i);
		
                    g.drawLine(o.x+parent.baseunit*(parent.finalTime+1), o.y+i, 
				   o.x+parent.baseunit*(parent.finalTime+1)-10, o.y+i+10);
                    g.drawLine(o.x+parent.baseunit*(parent.finalTime+1),  o.y+i, 
				   o.x+parent.baseunit*(parent.finalTime+1)-10, o.y+i-10);
                }
                //System.out.println("13123123123123123123123123123,,,,,"+ID);
                drawPeriod(g);
		
                for(int i=0;i<=parent.finalTime;i++)
		{ 
			g.drawLine(o.x+i*parent.baseunit, o.y, o.x+i*parent.baseunit, o.y+5);
			if(parent.parent.scale>=1)
			{
                                g.drawString(""+i, o.x+i*parent.baseunit-2, o.y+20);
			}
			else if(parent.parent.scale==(-8))
			{
                            if(i%10==0)
                                g.drawString(""+i,  o.x+i*parent.baseunit-2,  o.y+20);
			}
			else if(i%5==0)
			{
				g.drawString(""+i, o.x+i*parent.baseunit-2, o.y+20);			
			}
                }
               
		for(TaskExecution te : executions)
		{
                  
                        if(!te.status.equals("E"))
                        {
                            
                            if(te.status.equals("X"))
                            {
                                g.setColor(Color.red);
                                g.drawString("X", (int)(o.x-3+te.startTime*parent.baseunit), o.y-75);
                                g.setColor(Color.BLACK);
               //System.out.print(te.status);
                            }
                              
               //System.out.print(te.state);
                        }
                        else
                        {
                            
                            g.drawRect((int)(o.x + te.startTime*parent.baseunit), o.y-this.taskHeight, (int)(te.executionTime*parent.baseunit), this.taskHeight);
                            g.drawLine((int)(o.x + te.startTime*parent.baseunit), o.y, (int)(o.x + te.startTime*parent.baseunit), o.y+5);
                        
                            DecimalFormat df = new DecimalFormat("##.00");
                       
                            double time = Double.parseDouble(df.format(te.startTime));
                            if(((int)(time*10)%10)!=0)
                            {
                                g.drawString(""+ time,(int)(o.x-4+te.startTime*parent.baseunit), o.y+40);
                                g.drawLine((int)(o.x + te.startTime*parent.baseunit), o.y, (int)(o.x + te.startTime*parent.baseunit), o.y+25);
                        
                            }
                        
                            time = Double.parseDouble(df.format(te.endTime));
                        
                            if(((int)(time*10)%10)!=0)
                            {
                                g.drawString(""+ time,(int)(o.x-4+te.endTime*parent.baseunit), o.y+40);
                                g.drawLine((int)(o.x + te.endTime*parent.baseunit), o.y, (int)(o.x + te.endTime*parent.baseunit), o.y+25);
                            }
                        /*
                        int i=0;
			
                        for(String s:te.resources)
			{
				if(!s.equals("0") && !s.equals(null))
				{
					i++;
					Resources re=new Resources(this,s,te,i,reverseColor(resourceColor[ new Integer(s).intValue() -1]));
                                        this.parent.parent.getResultViewer().add(re);
                                        re.setBounds((int)(o.x + te.startTime*parent.baseunit), o.y-i*this.resourceHeight, (int)(te.executionTime*parent.baseunit), this.resourceHeight);
                                        re.setBackground(resourceColor[ new Integer(s).intValue() -1]);
                                        re.setToolTipText("R"+s+"(1)");
                                        
                                        //re.paintComponents(g);
                                        //g.fillRect((int)(o.x + te.startTime*parent.baseunit), o.y-i*this.resourceHeight, (int)(te.executionTime*parent.baseunit), this.resourceHeight);
					//g.setXORMode(resourceColor[ new Integer(s).intValue() -1]);
                                        
                                        //g.setColor(reverseColor(resourceColor[ new Integer(s).intValue() -1]));
                                       // g.drawString("R"+s+"(1)",(int)(o.x + te.startTime*parent.baseunit), o.y+12-i*this.resourceHeight);
                                        g.setColor(Color.black);
                                        
				}
			}
                                */
                    }
		}
		
		g.drawString("Task" + ID, o.x - 50, o.y);
		g.drawString("time", o.x+parent.baseunit*(parent.finalTime+1)+15, o.y+5);
	}
        
        
	public void drawPeriod(Graphics g)
	{
            TaskSet ts = this.parent.dr.getDataSetting().getTaskSet();
            int curPeriod = 0;
            int x = (ts.get(this.ID-1).getPeriod() - ts.get(this.ID-1).getRelativeDeadline()) / 100000;
            int[] xPoints = null, yPoints;
            g.setColor(Color.BLUE);
            for(int j = 0 ; j < ( parent.finalTime/(ts.get(this.ID-1).getPeriod()/100000) ) ; j++)
            {  
                    g.fillRect(o.x-1+parent.baseunit*curPeriod, o.y-100, 3, 15);
                    for(int k=1 ; k<3 ; k++)
                    {
                        g.drawLine(o.x+parent.baseunit*curPeriod, o.y-100-k, o.x-5+parent.baseunit*curPeriod, o.y-97-k);
                        g.drawLine(o.x+parent.baseunit*curPeriod, o.y-100-k, o.x+5+parent.baseunit*curPeriod, o.y-97-k);
                    }
                    
                    curPeriod+=ts.get(this.ID-1).getPeriod()/100000;
                    
                    g.fillRect(o.x-1+parent.baseunit*(curPeriod - x), o.y-100, 3, 15);
                    for(int k=1 ; k<3 ; k++)
                    {
                        g.drawLine(o.x+parent.baseunit*(curPeriod - x), o.y-85-k, o.x-5+parent.baseunit*(curPeriod - x), o.y-88-k);
                        g.drawLine(o.x+parent.baseunit*(curPeriod - x), o.y-85-k, o.x+5+parent.baseunit*(curPeriod - x), o.y-88-k);
                    }
            }       
            
           // System.out.println("123123123============"+"," + parent.finalTime + "," + ts.get(i).getPeriod()/100000 + "," + parent.finalTime/(ts.get(i).getPeriod()/100000) +","+x);
            g.setColor(Color.BLACK);
        }
        
        //public void drawResources(ResultViewer rv ,Graphics g, Color[] resourceColor)
	public void drawResources(ResultViewer rv, Color[] resourceColor)
	
        {
            for(TaskExecution te : executions)
            {
                if(te.status.equals("E"))
                {
                    int i=0;
                    for(String s:te.resources)
                    {
                        if(!s.equals("0") && !s.equals(null))
                        {
                            i++;
                            Resources resources = te.re.get(s);
                            rv.add(resources);
                            resources.setBounds((int)(o.x + te.startTime*parent.baseunit), o.y-i*this.resourceHeight, (int)(te.executionTime*parent.baseunit), this.resourceHeight);
                            resources.setToolTipText("R"+s+"(1)");
                            
                            char[] data = String.valueOf("R"+s+"(1) ").toCharArray();
                           
                        }
                    }
                }
            }
        }
        
        
        
        public void reDrawResources(ResultViewer rv ,Graphics g, Color[] resourceColor)
        {
            for(TaskExecution te : executions)
            {
                if(te.status.equals("E"))
                {
                    int i=0;
                    for(String s:te.resources)
                    {
                        if(!s.equals("0") && !s.equals(null))
                        {
                            i++;
                            Resources resources = te.re.get(s);
                            resources.setBounds((int)(o.x + te.startTime*parent.baseunit), o.y-i*this.resourceHeight, (int)(te.executionTime*parent.baseunit), this.resourceHeight);
                            resources.setToolTipText("R"+s+"(1)");
                            System.out.println("zzzzzzdï="+rv.getComponentZOrder(resources));
                            g.setColor(resourceColor[ new Integer(s).intValue() -1]);
                            g.fillRect((int)(o.x + te.startTime*parent.baseunit)+1, o.y-i*this.resourceHeight, (int)(te.executionTime*parent.baseunit)-1, this.resourceHeight);
                            g.setColor(reverseColor(resourceColor[ new Integer(s).intValue() -1]));
                            
                            
                            char[] data = String.valueOf("R"+s+"(1) ").toCharArray();
                            
                            if((int)(te.executionTime*parent.baseunit)>data.length*8)
                            {
                                g.drawChars(data, 0, data.length, (int)(o.x + te.startTime*parent.baseunit)+2, o.y-i*this.resourceHeight+this.resourceHeight-2);
                            }
                            else if((int)((te.executionTime*parent.baseunit)/8)>1)
                            {
                                    g.drawChars(data, 0, (int)((te.executionTime*parent.baseunit)/8), (int)(o.x + te.startTime*parent.baseunit)+2, o.y-i*this.resourceHeight+this.resourceHeight-2);
                            
                            }
                            //g.drawChars(data, 0, 5, (int)(o.x + te.startTime*parent.baseunit)+2, o.y-i*this.resourceHeight+this.resourceHeight-2);
                            g.setColor(Color.BLACK);
                            
                        }
                    }
                }
            }
        }
        

        public Color reverseColor(Color color){  
            int r = color.getRed();  
            int g = color.getGreen();  
            int b = color.getBlue();  
            int r_ = 255-r;  
            int g_ = 255-g;  
            int b_ = 255-b;  
            
            Color newColor = new Color(r_,g_,b_);  
            
            return newColor;  
        }  
}
