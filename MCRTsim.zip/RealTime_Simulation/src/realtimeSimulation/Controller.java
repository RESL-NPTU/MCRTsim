/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package realtimeSimulation;

import realtimeSimulation.concurrencyControlProtocol.implementation.SRP;
import realtimeSimulation.concurrencyControlProtocol.implementation.PCP;
import realtimeSimulation.concurrencyControlProtocol.ConcurrencyControlProtocol;
import realtimeSimulation.concurrencyControlProtocol.implementation.NPCS;

/**
 *
 * @author ShiuJia
 */
public class Controller
{
    private ConcurrencyControlProtocol concurrencyControlProtocol;
    private ResourceSet resourceSet;
    private Processor processor;
    
    public Controller()
    {
        
    }
    
    public void setCCProtocol(ConcurrencyControlProtocol cc)
    {
        this.concurrencyControlProtocol = cc;
    }
    
    public ConcurrencyControlProtocol getCCProtocol()
    {
        return this.concurrencyControlProtocol;
    }
    
    public void setResourceSet(ResourceSet rs)
    {
        this.resourceSet = rs;
    }
    
    public ResourceSet getResourceSet()
    {
        return this.resourceSet;
    }
    
    public void setProcessor(Processor p)
    {
        this.processor = p;
    }
    
    public Processor getProcessor()
    {
        return this.processor;
    }
    
    public boolean lockControl(Job j)
    {
        while((j.getLockResource().peek() != null) && (j.getLockResource().peek().getStartTime() <= Math.floor(j.getProgressAmount())))
        {
            CriticalSection cs = j.getLockResource().poll();
            Resource result = this.concurrencyControlProtocol.checkLock(j, cs.getResource()); //return阻擋工作之資源，null為工作j可鎖定資源cs.getResource
            if(result == null)
            {
                j.lock(cs);
                j.getLocationCore().setResourceChange();
            }
            else
            {
                if(this.concurrencyControlProtocol.isPIP())
                {
                    result.whoLocked().inheritCurrentPriorityBy(j);
                    result.blocked(j);
                }
                j.getLockResource().offer(cs);
                return false;
            }
        }
        return true;
    }
    
    public void unlockControl(Job j)
    {
        if((j.getLockedResource().size() > 0) && (j.getLockedResource().peek().getEndTime() <= Math.ceil(j.getProgressAmount())))
        {
            j.unLock(j.getLockedResource().pop());
            j.getLocationCore().setResourceChange();
        }
        if(j.getLockedResource().size() == 0)
        {
            j.getLocationCore().setPreemptible(true);
        }
    }
}
