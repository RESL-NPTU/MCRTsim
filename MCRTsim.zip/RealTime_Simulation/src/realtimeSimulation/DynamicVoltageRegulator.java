/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package realtimeSimulation;

import realtimeSimulation.dynamicVoltageAndFrequencyScaling.DynamicVoltageAndFrequencyScalingMethod;
import realtimeSimulation.dynamicVoltageAndFrequencyScaling.implementation.None;
import realtimeSimulation.dynamicVoltageAndFrequencyScaling.implementation.Test;

/**
 *
 * @author ShiuJia
 */
public class DynamicVoltageRegulator
{
    private DynamicVoltageAndFrequencyScalingMethod dynamicVoltageAndFrequencyScaling;
    private Core core;
    
    public DynamicVoltageRegulator()
    {
        
    }
    
    public void setDVFSMethod(DynamicVoltageAndFrequencyScalingMethod method)
    {
        this.dynamicVoltageAndFrequencyScaling = method;
        this.dynamicVoltageAndFrequencyScaling.setVoltageScaling(this);
    }
    
    public DynamicVoltageAndFrequencyScalingMethod getDVFSMethod()
    {
        return this.dynamicVoltageAndFrequencyScaling;
    }
    
    public void setCore(Core c)
    {
        this.core = c;
    }
    
    public Core getCore()
    {
        return this.core;
    }
    
    public void scaling()
    {
        this.dynamicVoltageAndFrequencyScaling.scalingVoltage();
    }
}
