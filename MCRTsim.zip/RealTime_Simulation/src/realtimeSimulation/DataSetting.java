/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package realtimeSimulation;

/**
 *
 * @author ShiuJia
 */
public class DataSetting
{
    private TaskSet taskSet;
    private ResourceSet resourceSet;
    private Processor processor;
    
    public DataSetting()
    {
        this.taskSet = new TaskSet();
        this.resourceSet = new ResourceSet();
        this.processor = new Processor();
    }
    
    public void setTaskSet(TaskSet ts)
    {
        this.taskSet = ts;
    }
    
    public TaskSet getTaskSet()
    {
        return this.taskSet;
    }
    
    public Task getTaskSet(int i)
    {
        return this.taskSet.get(i);
    }
    
    public void setResourceSet(ResourceSet rs)
    {
        this.resourceSet = rs;
    }
    
    public ResourceSet getResourceSet()
    {
        return this.resourceSet;
    }
    
    public Resource getResourceSet(int i)
    {
        return this.resourceSet.get(i);
    }
    
    public void setProcessor(Processor p)
    {
        this.processor = p;
    }
    
    public Processor getProcessor()
    {
        return this.processor;
    }
}
