/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package realtimeSimulation;

import java.util.Stack;
import java.util.Vector;

/**
 *
 * @author ShiuJia
 */
public class Result
{
    private double startTime, endTime;
    private Speed speed;
    private Status status;
    private Job job;
    private Stack<LockInfo> lockedResource;
    private Vector<Integer> priorityCeiling;
    private Vector<Integer> preemptibleCeiling;
    
    public Result(double t, Status s, Speed sp, Job j)
    {
        this.startTime = t;
        this.status = s;
        this.speed = sp;
        this.job = j;
        lockedResource = new Stack<>();
        priorityCeiling = new Vector<>();
        preemptibleCeiling = new Vector<>();
        if(s.equals(Status.EXECUTION))
        {
            this.lockedResource.addAll(j.getLockedResource());
        }
        for(int i = 0 ; i<lockedResource.size() ; i++)
        {
            priorityCeiling.add(j.getLockedResource().get(i).getResource().getPriorityCeiling().getValue());
            preemptibleCeiling.add(j.getLockedResource().get(i).getResource().getPreemptionLevelCeiling().getValue());       
        }
        
    }
    
    
    public double getStartTime()
    {
        return this.startTime;
    }
    
    public void setEndTime(Double t)
    {
        this.endTime = t;
    }
    
    public double getEndTime()
    {
        return this.endTime;
    }
    
    public Speed getSpeed()
    {
        return this.speed;
    }
    
    public Status getStatus()
    {
        return this.status;
    }
    
    public Job getJob()
    {
        return this.job;
    }
    
    
    public Stack<LockInfo> getLockedResource()
    {
        return this.lockedResource;
    }
    
    public Integer getPriorityCeiling(int i)
    {
        return this.priorityCeiling.get(i);
    }
    public Integer getPreemptibleCeiling(int i)
    {
        return this.preemptibleCeiling.get(i);
    }
    
}
