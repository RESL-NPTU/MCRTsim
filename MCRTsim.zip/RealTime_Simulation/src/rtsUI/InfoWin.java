/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rtsUI;

import java.awt.EventQueue;
import java.awt.event.*;
import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JToolBar;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Graphics;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.Vector;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JScrollBar;
import javax.swing.SwingConstants;
import realtimeSimulation.Core;
import realtimeSimulation.DataReader;
import realtimeSimulation.Result;
import rtsUI.resultViewer.*;
/**
 *
 * @author ShiuJia
 */
public class InfoWin extends JPanel
{
        
    public UserInterface parent;
    //private Graphics g;
    private JFrame frame;
    private JScrollPane scrollPane;
    public JLabel message;
    public JLabel timeMessage;
    
    private JButton drawBtn;
    private JButton timeLineBtn;
    
    private JButton btnZoomIn, btnZoomOut;
    private ScheduleResult sr;
    private ResultViewer rv;
    public int scale=1;
    public int mouseX=0;

	
    public InfoWin(UserInterface ui) 
    {
        super();
        this.parent = ui;
        this.setLayout(new BorderLayout()); 
        initialize();
               
        /*
	sr = new ScheduleResult(this);
	rv = new ResultViewer(sr);
	scrollPane.setViewportView(rv);
	InfoWin.this.message.setText("1x");
	InfoWin.this.rv.setPreferredSize(new Dimension(sr.finalTime*sr.baseunit+200, 
			sr.numTasks*150+100));
	InfoWin.this.rv.revalidate();
        */
        
        this.scrollPane.getHorizontalScrollBar().getAdjustmentListeners();
        
        this.timeLineBtn.addMouseListener(new MouseAdapter(){
            public void mouseClicked(MouseEvent e)
            {
                InfoWin.this.timeLineBtn.setForeground(InfoWin.this.timeLineBtn.getForeground()
                        ==Color.red? Color.GREEN : Color.red);
                InfoWin.this.rv.mouseStatus.chengeMouseStatus();
                InfoWin.this.rv.repaint();
            }
        });
        
        
            
        
        this.drawBtn.addMouseListener(new MouseAdapter(){
            public void mouseClicked(MouseEvent e)
            {
                DataReader dr = InfoWin.this.parent.getSimulationViewer().getDataReader();
                System.out.println("123");
                Vector<Core> cr = dr.getDataSetting().getProcessor().getCores();
                System.out.println(cr.size());
            
                Vector<Result> rcd =cr.get(0).getRecord();
                System.out.println(rcd.size());
            
                sr = new ScheduleResult(InfoWin.this);
                rv = new ResultViewer(sr);
                scrollPane.setViewportView(rv);
                scrollPane.getHorizontalScrollBar().setUnitIncrement(16);
                scrollPane.getVerticalScrollBar().setUnitIncrement(16);
                InfoWin.this.message.setText("1x");
                InfoWin.this.rv.setPreferredSize(new Dimension(sr.finalTime*sr.baseunit+200, 
                               		sr.numTasks*150+100));
                InfoWin.this.timeLineBtn.setForeground(Color.red);
            
                InfoWin.this.parent.getAttributes().getTimeLineSet().removeAllItems();
                InfoWin.this.rv.revalidate();
                
                rv.setVisible(true);
                
                
            }
        });
        
        
        
        
        
	btnZoomIn.addMouseListener(new MouseAdapter()
	{
        	public void mouseClicked(MouseEvent e)
		{
			if(scale<0)
			{
				scale/=2;
				if(scale==(-1))
					scale=1;
                            InfoWin.this.sr.baseunit*=2;
                            InfoWin.this.rv.repaint();
                        }
			else if(scale < 16)
			{
                            InfoWin.this.sr.baseunit*=2;
                            InfoWin.this.rv.repaint();
                            scale*=2;
			}
        
			if(scale <= 16)
			{
        			if(scale<0)
				InfoWin.this.message.setText("1/" + Math.abs(scale) + "x");
				else
					InfoWin.this.message.setText("" + scale + "x");
			}
                        InfoWin.this.rv.setPreferredSize(new Dimension(sr.finalTime*sr.baseunit+200, 
                                                                    sr.numTasks*150+100));
			
		}
                
	});
	
	btnZoomOut.addMouseListener(new MouseAdapter()
	{
		public void mouseClicked(MouseEvent e)
		{
			if(scale>1)
                        {
                            scale/=2;
                            InfoWin.this.sr.baseunit/=2;
                            InfoWin.this.rv.repaint();
                        }
                        else if(scale==1)
                        {
                            scale=(-2);
                            InfoWin.this.sr.baseunit/=2;
                            InfoWin.this.rv.repaint();
                        }
			else if((scale<0)&&(scale>(-8)))
			{
				scale*=2;
                                InfoWin.this.sr.baseunit/=2;
				InfoWin.this.rv.repaint();
			}

                        if(scale>=(-8))
			{
				if(scale<0)
					InfoWin.this.message.setText("1/" + Math.abs(scale) + "x");
				else
					InfoWin.this.message.setText("" + scale + "x");
			}
			else
			{
				scale=(-8);
			}
				
			InfoWin.this.rv.setPreferredSize(new Dimension(sr.finalTime*sr.baseunit+200,
                                                            sr.numTasks*150+100));
			
		}
			
			
	});
	
}
   

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
                JToolBar toolBar = new JToolBar();
		this.add(toolBar,BorderLayout.NORTH);
		
		btnZoomIn = new JButton("Zoom In");
		toolBar.add(btnZoomIn);
		
		btnZoomOut = new JButton("Zoom Out");
		toolBar.add(btnZoomOut);
                
                this.drawBtn = new JButton("Draw");
                toolBar.add(this.drawBtn);
                this.drawBtn.setForeground(Color.BLUE);
                
                this.timeLineBtn =new JButton("timeLine");
                toolBar.add(this.timeLineBtn);
                this.timeLineBtn.setForeground(Color.red);
		
		JPanel panel = new JPanel();
		this.add(panel, BorderLayout.SOUTH);
		panel.setLayout(new BorderLayout(0, 0));
				
		message = new JLabel("Message Here");
		message.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(message, BorderLayout.WEST);
                
                
                timeMessage = new JLabel("Message Here");
                timeMessage.setHorizontalAlignment(SwingConstants.CENTER);
                panel.add(timeMessage, BorderLayout.CENTER);
                 
                scrollPane = new JScrollPane();
		this.add(scrollPane, BorderLayout.CENTER);
        }
        
        public ScheduleResult getScheduleResult()
        {
            return this.sr;
        }

        public ResultViewer getResultViewer()
        {
            return this.rv;
        }
        
        public JScrollPane getRVscrollPane()
        {
            return this.scrollPane;
        }
        
        
        
}
