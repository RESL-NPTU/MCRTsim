/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package realtimeSimulation;

import java.lang.reflect.Constructor;
import realtimeSimulation.concurrencyControlProtocol.ConcurrencyControlProtocol;
import realtimeSimulation.concurrencyControlProtocol.implementation.NPCS;
import realtimeSimulation.concurrencyControlProtocol.implementation.PCP;
import realtimeSimulation.concurrencyControlProtocol.implementation.SRP;
import realtimeSimulation.dynamicVoltageAndFrequencyScaling.DynamicVoltageAndFrequencyScalingMethod;
import realtimeSimulation.schedulingAlgorithm.DynamicPrioritySchedulingAlgorithm;
import realtimeSimulation.schedulingAlgorithm.FixedPrioritySchedulingAlgorithm;
import realtimeSimulation.schedulingAlgorithm.PriorityDrivenSchedulingAlgorithm;

/**
 *
 * @author ShiuJia
 */
public class Simulator
{
    private int systemTime;
    private Scheduler scheduler;
    private Controller controller;
    private Processor processor;
    private TaskSet taskSet;
    private ResourceSet resourceSet;
    private JobQueue globalReadyQueue;
    private JobQueue waitQueue;
    private DynamicVoltageRegulator dynamicVoltageRegulator;
    private long simulationTime;
    
    public Simulator()
    {
        this.systemTime = 0;
        this.scheduler = new Scheduler();
        this.controller = new Controller();
        this.taskSet = new TaskSet();
        this.resourceSet = new ResourceSet();
        this.processor = new Processor();
        this.globalReadyQueue = new JobQueue();
        this.waitQueue = new JobQueue();
        this.dynamicVoltageRegulator = new DynamicVoltageRegulator();
    }
    
    public void start()
    {
        
        
        while(this.systemTime < this.simulationTime + 100000)
        {
            this.checkTaskPeriod();
            if(this.scheduler.getSchedulingAlgorithm() instanceof DynamicPrioritySchedulingAlgorithm) //動態優先權分配
            {
                this.globalReadyQueue = this.scheduler.setPriority(this.globalReadyQueue);
            }
            
            //分配Job至各Processor之Core
            Job j = new Job();
            while((j = this.globalReadyQueue.poll()) != null)
            {
                this.processor.getCores().get(0).getLocalReadyQueue().add(j);
                j.setLocationCore(this.processor.getCores().get(0));
                j.setCriticalSectionSet();
            }
            
            this.processor.run(1);
            this.systemTime += 1;
            this.checkJobMissDeadline();
        }
        this.processor.getCores().get(0).getRecord().get(this.processor.getCores().get(0).getRecord().size() - 1).setEndTime((double)this.systemTime/100000);
        System.out.println("-1");
    }
    
    public int getSystemTime()
    {
        return this.systemTime;
    }
    
    public void setSchedAlgorithm(PriorityDrivenSchedulingAlgorithm algorithm)
    {
        this.scheduler.setSchedAlgorithm(algorithm);
        
        if(this.scheduler.getSchedulingAlgorithm() instanceof FixedPrioritySchedulingAlgorithm) //靜態優先權分配
        {
            this.scheduler.setPriority(this.taskSet);
        }
    }
    
    public Scheduler getScheduler()
    {
        return this.scheduler;
    }
    
    public void setCCProtocol(ConcurrencyControlProtocol cc)  
    {
        this.controller.setCCProtocol(cc);
    }
    
    public Controller getController()
    {
        return this.controller;
    }
    
    public void setDVFSMethod(DynamicVoltageAndFrequencyScalingMethod method)
    {
        this.dynamicVoltageRegulator.setDVFSMethod(method);
    }
    
    public DynamicVoltageRegulator getDynamicVoltageRegulator()
    {
        return this.dynamicVoltageRegulator;
    }
    
    public void loadDataSetting(DataSetting ds)
    {
        this.processor = ds.getProcessor();
        this.processor.setSimulation(this);
        for(int i = 0; i < this.processor.getCores().size(); i++)
        {
            this.processor.getCores().get(i).setController(this.controller);
            this.processor.getCores().get(i).setDynamicVoltageRegulator(this.dynamicVoltageRegulator);
        }
        this.controller.setProcessor(this.processor);
        
        this.taskSet = ds.getTaskSet();
        
        this.resourceSet = ds.getResourceSet();
        this.controller.setResourceSet(this.resourceSet);
    }
    
    public Processor getProcessor()
    {
        return this.processor;
    }
    
    public TaskSet getTaskSet()
    {
        return this.taskSet;
    }
    
    public ResourceSet getResourceSet()
    {
        return this.resourceSet;
    }
    
    public JobQueue getReadyQueue()
    {
        return this.globalReadyQueue;
    }
    
    public JobQueue getWaitQueue()
    {
        return this.waitQueue;
    }
    
    public void checkTaskPeriod()
    {
        for(int i = 0; i < this.taskSet.size(); i++)
        {
            if(this.systemTime % this.taskSet.get(i).getPeriod() == 0)
            {
                this.globalReadyQueue.offer(this.taskSet.get(i).newJob(this.systemTime, this.processor));
            }
        }
    }
    
    public void checkJobMissDeadline()
    {
        for(int i = 0; i < this.processor.getCores().size(); i++)
        {
            JobQueue newJq = new JobQueue();
            Job j;
            
            while((j = this.processor.getCores().get(i).getLocalReadyQueue().poll()) != null)
            {
                if(j.getAbsoluteDeadline() <= this.systemTime) //Job j MissDeadline
                {
                    if(j.getLocationCore().getRecord().size() > 0)
                    {
                        j.getLocationCore().getRecord().get(j.getLocationCore().getRecord().size() - 1).setEndTime((double)this.systemTime / 100000);
                    }
                    j.getLocationCore().getRecord().add(new Result((double)this.systemTime / 100000, Status.WRONG, null, j));
                    System.out.println((double)this.systemTime / 100000 + ":X:" + j.getTask().getID());
                    
                    while(j.getLockedResource().size() > 0 && j.getLockedResource().peek() != null)
                    {
                        j.unLock(j.getLockedResource().pop());
                    }
                }
                else
                {
                    newJq.offer(j);
                }
            }
            this.processor.getCores().get(i).setLocalReadyQueue(newJq);
        }
    }
    
    public void setSimulationTime(long i)
    {
        this.simulationTime = i * 100000;
    }
    public long getSimulationTime()
    {
        return this.simulationTime / 100000;
    }
}
