/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package realtimeSimulation;

/**
 *
 * @author ShiuJia
 */
public class Task
{
    private int ID; // 代碼
    private int numJob = 0; // number of jobs that have been created
    private int period; // 週期
    private int relativeDeadline; // 相對截止時間
    private int computationAmount; // 以最高速度運作所需工作量(the value is assigned for the task running at maxProcessingSpeed)
    private int maxProcessingSpeed; // 單位=MHz
    private Priority priority; // 使用於固定式優先權分配(only for fixed-priority assignment)
    private ResourceSet resourceSet; // 運作時所需使用之資源
    private CriticalSectionSet criticalSectionSet; // 所有使用資源的時段
    private Priority preemptionLevel;
    
    public Task()
    {
        this.priority = new Priority();
        this.preemptionLevel = new Priority();
    }
    
    public void setID(int i)
    {
        this.ID = i;
    }
    
    public int getID()
    {
        return this.ID;
    }
    
    public int getNumJob()
    {
        return this.numJob;
    }
    
    public void setPeriod(int p)
    {
        this.period = p;
    }
    
    public int getPeriod()
    {
        return this.period;
    }
    
    public void setRelativeDeadline(int r)
    {
        this.relativeDeadline = r;
    }
    
    public int getRelativeDeadline()
    {
        return this.relativeDeadline;
    }
    
    public void setComputationAmount(int c)
    {
        this.computationAmount = c;
    }
    
    public int getComputationAmount()
    {
        return this.computationAmount;
    }
    
    public void setMaxProcessingSpeed(int mps)
    {
        this.maxProcessingSpeed = mps;
    }
    
    public int getMaxProcessingSpeed()
    {
        return this.maxProcessingSpeed;
    }
    
    public void setPriority(Priority p)
    {
        this.priority = p;
    }
    
    public Priority getPriority()
    {
        return this.priority;
    }
    
    public void setPreemptionLevel(Priority p)
    {
        this.preemptionLevel = p;
    }
    
    public Priority getPreemptionLevel()
    {
        return this.preemptionLevel;
    }
    
    public void setCriticalSectionSet(CriticalSectionSet css)
    {
        this.criticalSectionSet = css;
    }
    
    public CriticalSectionSet getCriticalSectionSet()
    {
        return this.criticalSectionSet;
    }
    
    public Job newJob(int systemTime, Processor processor) //產生新Job
    {
        this.numJob++;
        Job j = new Job();
        j.setTask(this);
        j.setReleaseTime(systemTime);
        j.setID(this.numJob);
        j.setAbsoluteDeadline(this.relativeDeadline * this.numJob);
        j.setProgressAmount(0);
        j.setTargetAmount(this.computationAmount);
        j.setOriginalPriority(this.priority);
        j.setCurrentPriority(this.priority);
        return j;
    }
    
    public boolean isPriorityHigher(Priority p)
    {
        if(this.priority.getValue() > p.getValue())
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    public boolean isPreemptionLevelHigher(Priority p)
    {
        if(this.preemptionLevel.getValue() > p.getValue())
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}
