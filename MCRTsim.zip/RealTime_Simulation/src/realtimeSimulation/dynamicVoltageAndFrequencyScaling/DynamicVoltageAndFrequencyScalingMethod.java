/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package realtimeSimulation.dynamicVoltageAndFrequencyScaling;

import realtimeSimulation.DynamicVoltageRegulator;

/**
 *
 * @author ShiuJia
 */
public abstract class DynamicVoltageAndFrequencyScalingMethod
{
    private String methodName;
    private DynamicVoltageRegulator voltageScaling;
    
    public DynamicVoltageAndFrequencyScalingMethod()
    {
        
    }
    
    public void setName(String name)
    {
        this.methodName = name;
    }
    
    public String getName()
    {
        return this.methodName;
    }
    
    public void setVoltageScaling(DynamicVoltageRegulator s)
    {
        this.voltageScaling = s;
    }
    
    public DynamicVoltageRegulator getVoltageScaling()
    {
        return this.voltageScaling;
    }
    
    public abstract void scalingVoltage();
}
