/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package realtimeSimulation.concurrencyControlProtocol.implementation;

import java.util.Vector;
import realtimeSimulation.Controller;
import realtimeSimulation.DataSetting;
import realtimeSimulation.Final;
import realtimeSimulation.Job;
import realtimeSimulation.Priority;
import realtimeSimulation.Resource;
import realtimeSimulation.concurrencyControlProtocol.ConcurrencyControlProtocol;
import realtimeSimulation.concurrencyControlProtocol.ConcurrencyControlProtocol;

/**
 *
 * @author ShiuJia
 */
public class SRP extends ConcurrencyControlProtocol //問題一
{
    public SRP(DataSetting ds)
    {
        super(ds);
        this.setName("Stack Resource Policy");
        this.setPIP(true);
        
        Vector<Integer> in = new Vector<Integer>();
        for(int i = 0; i < this.getDataSetting().getTaskSet().size(); i++)
        {
            in.add(0);
        }
        for(int i = 0; i < this.getDataSetting().getTaskSet().size() - 1; i++)
        {
            for(int j = i + 1; j < this.getDataSetting().getTaskSet().size(); j++)
            {
                if(this.getDataSetting().getTaskSet(i).getPeriod() < this.getDataSetting().getTaskSet(j).getPeriod())
                {
                    in.set(i, in.get(i) - 1);
                }
                else
                {
                    in.set(j, in.get(j) - 1);
                }
            }
        }
        for(int i = 0; i < this.getDataSetting().getTaskSet().size(); i++)
        {
            this.getDataSetting().getTaskSet(i).setPreemptionLevel(new Priority(in.get(i) + this.getDataSetting().getTaskSet().size()));
        }
        
        
        
        for(int i = 0; i < this.getDataSetting().getResourceSet().size(); i++)
        {
            this.getDataSetting().getResourceSet(i).setPreemptionLevelCeiling(Final.Ohm);
            for(int j = 0; j < this.getDataSetting().getResourceSet().get(i).getAccessSet().size(); j++)
            {
                if(this.getDataSetting().getResourceSet(i).getAccessSet().get(j).isPreemptionLevelHigher(this.getDataSetting().getResourceSet(i).getPreemptionLevelCeiling()))
                {
                    this.getDataSetting().getResourceSet(i).setPreemptionLevelCeiling(this.getDataSetting().getResourceSet(i).getAccessSet().get(j).getPreemptionLevel());
                }
            }
        }
    }

    @Override
    public Resource checkLock(Job j, Resource r)
    {
        if(r.whoLocked() == null) //檢查使用資源是否已被Lock：通過
        {
            if(j.isPreemptionLevelHigher(this.getSystemPreemptionLevelCeiling(j))) //檢查SystemPreemptionLevelCeiling：通過
            {
                for(int i = 0; i < j.getCriticalSectionSet().size(); i++)
                {
                    if(j.getCriticalSectionSet().get(i).getResource().whoLocked() != null && j.getCriticalSectionSet().get(i).getResource().whoLocked() != j) //檢查所有欲使用的資源：阻擋
                    {
                        return j.getCriticalSectionSet().get(i).getResource();
                    }
                }
                return null;
            }
            else //檢查SystemPreemptionLevelCeiling：阻擋
            {
                return this.ResourceOfSystemPreemptionLevelCeiling(j);
            }
        }
        else //檢查使用資源是否已被Lock：阻擋
        {
            return r;
        }
    }
    
    public Resource ResourceOfSystemPreemptionLevelCeiling(Job j)
    {
        Priority ceiling = Final.Ohm;
        Resource resource = null;
        for(int i = 0; i < this.getDataSetting().getResourceSet().size(); i++)
        {
            if(this.getDataSetting().getResourceSet(i).whoLocked() != null && this.getDataSetting().getResourceSet(i).whoLocked() != j)
            {
                if(this.getDataSetting().getResourceSet(i).isPreemptionLevelHigher(ceiling))
                {
                    ceiling = this.getDataSetting().getResourceSet(i).getPreemptionLevelCeiling();
                    resource = this.getDataSetting().getResourceSet(i);
                }
            }
        }
        return resource;
    }
    
    public Priority getSystemPreemptionLevelCeiling(Job j)
    {
        if(this.ResourceOfSystemPreemptionLevelCeiling(j) == null)
        {
            return Final.Ohm;
        }
        else
        {
            return this.ResourceOfSystemPreemptionLevelCeiling(j).whoLocked().getTask().getPreemptionLevel();
        }
    }
}
