/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rtsUI;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import java.util.Vector;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JToolBar;
import javax.swing.SwingConstants;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import realtimeSimulation.Result;

/**
 *
 * @author YC
 */
public class Attributes extends JPanel {

    private JComboBox<Double> timeLineSet;
    private JToolBar toolBar;
    private JPanel view;
    private UserInterface parent;
    
    private String startTime = "", endTime = "", Speed = "", Status = "", Resource = "", TaskID = "";
    private JTable table;

    private int numAbt;

    public Attributes(UserInterface ui) {
        super();
        parent = ui;
        init();

        this.timeLineSet.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (Attributes.this.timeLineSet.getItemCount() != 0) {
                    try {
                        Attributes.this.setAtbText(
                                Attributes.this.parent.getInfoWin().getScheduleResult().getAtbSet().get(
                                        Double.valueOf(
                                                Double.valueOf(
                                                        Attributes.this.timeLineSet.getSelectedItem().toString()
                                                ).doubleValue() * 100
                                        ).intValue()
                                )
                        );

                    } catch (Exception ex) {
                    }

                }
            }
        });

        this.timeLineSet.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                if (e.getStateChange() == ItemEvent.SELECTED) {

                    Attributes.this.parent.getInfoWin().getRVscrollPane().getHorizontalScrollBar().setValue(
                            Double.valueOf(
                                    Double.valueOf(
                                            Attributes.this.timeLineSet.getSelectedItem().toString()
                                    ).doubleValue() * Attributes.this.parent.getInfoWin().getScheduleResult().baseunit
                            ).intValue() + 100
                            - (Attributes.this.parent.getInfoWin().getRVscrollPane().getWidth() / 2)
                    );
                }
            }

        });

    }

    public void setAtbText(Result rd) {
try {
            this.TaskID="" + rd.getJob().getTask().getID();
        } catch (Exception ex) {
            this.TaskID="Null";
        }

        this.startTime="" + rd.getStartTime();
        this.endTime="" + rd.getEndTime();
        try {
            this.Speed="" + rd.getSpeed().getFrequency() + "_(" + rd.getSpeed().getNormalization() + ")";
        } catch (Exception ex) {
            this.Speed="Null";
        }
        this.Status="" + rd.getStatus();

        String str = "";
        if (rd.getLockedResource().size() != 0) {
            for (int i = 0; i < rd.getLockedResource().size(); i++) {

                str = str + 'R' + rd.getLockedResource().get(i).getResource().getID()
                        + "(" + (-rd.getLockedResource().get(i).getPriority().getValue()) + "," + (-rd.getPriorityCeiling(i)) + "," + (-rd.getPreemptibleCeiling(i)) + ")" + "<br>";

            }
        } else {
            str = "Null";
        }
        //this.table.setRowHeight(5, 30+30*(rd.getLockedResource().size()-1));
        this.Resource="<html>" + str + "<html>";
        
        table.getModel().setValueAt(this.TaskID,0,1);
        table.getModel().setValueAt(this.startTime,1,1);
        table.getModel().setValueAt(this.endTime,2,1);
        table.getModel().setValueAt(this.Speed,3,1);
        table.getModel().setValueAt(this.Status,4,1);
        table.getModel().setValueAt(this.Resource,5,1);

    }

    private void init() {
        this.setLayout(new BorderLayout());
        toolBar = new JToolBar();
        timeLineSet = new JComboBox<Double>();

        toolBar.add(new JLabel("Time:"));
        toolBar.add(timeLineSet);
        this.add(toolBar, BorderLayout.NORTH);


        String[] str = {"TaskID:", "StartTime:", "EndTime:", "Speed:", "Status:", "Resource:"};

        table = new JTable(str.length, 2) {

            public boolean isCellEditable(int row, int col) {
                return false;
            }

        };

        table.setBackground(Color.YELLOW);
        table.getColumnModel().getColumn(0).setMinWidth(70);
        table.getColumnModel().getColumn(0).setMaxWidth(70);
        table.getColumnModel().getColumn(1).setMinWidth(70);
        table.setRowHeight(30);
        table.setGridColor(Color.BLACK);

        DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
        renderer.setHorizontalAlignment(JLabel.RIGHT);
        table.getColumnModel().getColumn(0).setCellRenderer(renderer);
        
        for (numAbt = 0; numAbt < str.length; numAbt++) {
            table.getModel().setValueAt(str[numAbt], numAbt, 0);
        }
        
        table.setRowHeight(5, 100);
        this.add(table, BorderLayout.CENTER);

    }

    public JComboBox<Double> getTimeLineSet() {
        return this.timeLineSet;
    }

}
