/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package realtimeSimulation;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Iterator;
import java.util.Vector;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

/**
 *
 * @author ShiuJia
 */
public class DataReader
{
    private DataSetting ds;
    Element root;
    
    public DataReader()
    {
        this.ds = new DataSetting();
    }
    
    public void read(String source) throws FileNotFoundException, IOException, DocumentException
    {
        SAXReader reader = new SAXReader();
        Document document = reader.read(source);
        root = document.getRootElement();
        switch(root.getName())
        {
            case "Workload":
            {
                this.readWorkload();
                break;
            }
            case "Environment":
            {
                this.readEnvironment();
                break;
            }
        }
    }
    
    public void readWorkload() throws IOException
    {
        Iterator it = root.elementIterator();
        
        //建立ResourceSet
        for(int i = 0; i < Integer.valueOf(this.root.attribute("ResourceNumber").getText()); i++)
        {
            Resource res = new Resource();
            res.setID(i + 1);
            this.ds.getResourceSet().add(res);
        }
        
        //建立TaskSet
        while(it.hasNext())
        {
            Element taskElement = (Element)it.next();
            //System.out.println("Task:");
            Task task = new Task();
            //System.out.println("  TaskID:" + taskElement.attribute("ID").getText());
            task.setID(Integer.valueOf(taskElement.attribute("ID").getText()));
            //System.out.println("  TaskPeriod:" + taskElement.elementText("Period"));
            task.setPeriod((int)(Double.parseDouble(taskElement.elementText("Period"))*100000));
            //System.out.println("  TaskDeadline:" + taskElement.elementText("RelativeDeadline"));
            task.setRelativeDeadline((int)(Double.parseDouble(taskElement.elementText("RelativeDeadline"))*100000));
            //System.out.println("  TaskComputationAmount:" + taskElement.elementText("ComputationAmount"));
            task.setComputationAmount((int)(Double.parseDouble(taskElement.elementText("ComputationAmount"))*100000));
            
            Iterator cssIterator = taskElement.elementIterator("CriticalSection");
            CriticalSectionSet css = new CriticalSectionSet();
            while(cssIterator.hasNext())
            {
                Element cssElement = (Element)cssIterator.next();
                CriticalSection c = new CriticalSection();
                //System.out.println("    Resource:" + cssElement.elementText("Resource"));
                c.setResource(this.ds.getResourceSet().get(Integer.valueOf(cssElement.elementText("Resource")) - 1));
                this.ds.getResourceSet().get(Integer.valueOf(cssElement.elementText("Resource")) - 1).getAccessSet().add(task);
                //System.out.println("      StartTime:" + cssElement.elementText("StartTime"));
                c.setStartTime((int)(Double.parseDouble(cssElement.elementText("StartTime"))*100000));
                //System.out.println("      EndTime:" + cssElement.elementText("EndTime"));
                c.setEndTime((int)(Double.parseDouble(cssElement.elementText("EndTime"))*100000));
                css.add(c);
            }
            task.setCriticalSectionSet(css);
            //System.out.println("  Frequency:" + root.attribute("Frequency").getText());
            task.setMaxProcessingSpeed(Integer.valueOf(root.attribute("Frequency").getText()));
            this.ds.getTaskSet().add(task);
        }
    }
    
    public void readEnvironment() throws IOException
    {
        Iterator it = root.elementIterator();
        
        //建立Processor
        //System.out.println("ProcessorModel:" + root.attribute("ProcessorModel").getText());
        this.ds.getProcessor().setProcessorModel(root.attribute("ProcessorModel").getText());
        Vector<Core> cores = new Vector<Core>();
        
        //建立Core
        while(it.hasNext())
        {
            Element coreElement = (Element)it.next();
            //System.out.println("Core:");
            Core core = new Core();
            //System.out.println("  CoreID:" + coreElement.attribute("ID").getText());
            core.setID(Integer.valueOf(coreElement.attribute("ID").getText()));
            
            Element supportSpeedElement = coreElement.element("SupportSpeed");
            Iterator speedIterator = supportSpeedElement.elementIterator("Speed");
            Vector<Speed> ss = new Vector<Speed>();
            while(speedIterator.hasNext())
            {
                Element speedElement = (Element)speedIterator.next();
                Speed speed = new Speed();
                //System.out.println("    Frequency:" + speedElement.elementText("Frequency"));
                speed.setFrequency(Integer.valueOf(speedElement.elementText("Frequency")));
                //System.out.println("    Power:" + speedElement.elementText("Power"));
                speed.setPower(Integer.valueOf(speedElement.elementText("Power")));
                ss.add(speed);
            }
            for(int i = 0; i < ss.size(); i++)
            {
                ss.get(i).setNormalization((double)ss.get(i).getFrequency() / ss.get(ss.size() - 1).getFrequency());
                //System.out.println("NF = " + ss.get(i).getNormalization());
            }
            core.setSupportSpeed(ss);
            this.ds.getProcessor().addCore(core);
        }
    }
    
    public DataSetting getDataSetting()
    {
        return this.ds;
    }
}
