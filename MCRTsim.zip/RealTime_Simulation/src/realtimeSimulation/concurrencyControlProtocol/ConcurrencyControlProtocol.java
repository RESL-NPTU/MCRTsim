/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package realtimeSimulation.concurrencyControlProtocol;

import realtimeSimulation.Controller;
import realtimeSimulation.DataSetting;
import realtimeSimulation.Job;
import realtimeSimulation.Resource;

/**
 *
 * @author ShiuJia
 */
public abstract class ConcurrencyControlProtocol
{
    private String methodName;
    private Controller controller;
    private DataSetting dataSetting;
    private boolean setPIP;
    
    public ConcurrencyControlProtocol(DataSetting ds)
    {
        //this.controller = c;
        this.dataSetting = ds;
        this.setPIP = false;
    }
    
    public void setName(String name)
    {
        this.methodName = name;
    }
    
    public String getName()
    {
        return this.methodName;
    }
    
    public void setController(Controller c)
    {
        this.controller = c;
    }
    
    public Controller getController()
    {
        return this.controller;
    }
    
    public void setDataSetting(DataSetting ds)
    {
        this.dataSetting = ds;
    }
    
    public DataSetting getDataSetting()
    {
        return this.dataSetting;
    }
    
    public void setPIP(boolean is)
    {
        this.setPIP = is;
    }
    
    public boolean isPIP()
    {
        return this.setPIP;
    }        
    
    public abstract Resource checkLock(Job j, Resource r);
}
