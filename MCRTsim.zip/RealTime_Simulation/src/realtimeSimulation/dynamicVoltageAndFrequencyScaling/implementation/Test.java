/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package realtimeSimulation.dynamicVoltageAndFrequencyScaling.implementation;

import realtimeSimulation.dynamicVoltageAndFrequencyScaling.DynamicVoltageAndFrequencyScalingMethod;

/**
 *
 * @author ShiuJia
 */
public class Test extends DynamicVoltageAndFrequencyScalingMethod
{
    public Test()
    {
        this.setName("Test");
    }
    
    @Override
    public void scalingVoltage()
    {
        this.getVoltageScaling().getCore();
        if(this.getVoltageScaling().getCore().getWorkingJob().getLockedResource().size() > 0)
        {
            this.getVoltageScaling().getCore().setCurrentSpeed(this.getVoltageScaling().getCore().getSupportSpeed().get(this.getVoltageScaling().getCore().getSupportSpeed().size() - 1));
        }
        else
        {
            this.getVoltageScaling().getCore().setCurrentSpeed(this.getVoltageScaling().getCore().getSupportSpeed().get(0));
        }
    }
    
}
