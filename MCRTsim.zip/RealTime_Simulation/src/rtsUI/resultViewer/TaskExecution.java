/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rtsUI.resultViewer;

import java.util.ArrayList;
import java.util.Dictionary;
import java.util.Hashtable;

/**
 *
 * @author ShiuJia
 */
public class TaskExecution {
		
        double executionTime;
	double startTime;
        double endTime;
        String status;
        int speed;
	ArrayList<String> resources;
	Dictionary<String, Resources> re;
        
	public TaskExecution() {
		// TODO Auto-generated constructor stub
	}
	public TaskExecution(double s,double e, String sta, int sp)
	{
		startTime = s;
                endTime=e;
                status=sta;
                speed=sp;
                executionTime=endTime-startTime;
        }
        
	public TaskExecution(double s,double e, String sta, int sp, ArrayList<String> a)
	{
		startTime = s;
                endTime=e;
                status=sta;
                speed=sp;
		resources = a;
                re = new Hashtable<String, Resources>();
                for(String str : a)
                {
                    re.put(str, new Resources(this,str));
                }
                executionTime=endTime-startTime;
                
        }

  

}
