/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package realtimeSimulation;

/**
 *
 * @author ShiuJia
 */
public class LockInfo
{
    private Resource resource; //鎖定的Resource
    private double relativeEndTime;
    private Priority priority; //鎖定Resource前的優先權
    
    public LockInfo(Resource r, double rt, Priority p)
    {
        this.resource = r;
        this.relativeEndTime = rt;
        this.priority = p;
    }
    
    public Resource getResource()
    {
        return this.resource;
    }
    
    public double getEndTime()
    {
        return this.relativeEndTime;
    }
    
    public Priority getPriority()
    {
        return this.priority;
    }
}