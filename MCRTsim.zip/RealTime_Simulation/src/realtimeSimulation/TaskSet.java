/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package realtimeSimulation;

import java.util.Vector;

/**
 *
 * @author ShiuJia
 */
public class TaskSet extends Vector<Task>
{
    public long getLcmOfPeriodForTaskSet() // 取得TaskSet中所有工作的週期之最小公倍數
    {
        Equation e = new Equation();
        long lcm = this.get(0).getPeriod();
        for(int i = 1; i < this.size(); i++)
        {
            lcm = e.Math_lcm(lcm, this.get(i).getPeriod());
        }
        return lcm / 100000;
    }
}
