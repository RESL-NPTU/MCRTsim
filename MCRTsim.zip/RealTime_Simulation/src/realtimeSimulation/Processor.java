/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package realtimeSimulation;

import java.util.Iterator;
import java.util.Vector;

/**
 *
 * @author ShiuJia
 */
public class Processor
{
    private Simulator simulation;
    private String model;
    private Vector<Core> cores;
    
    public Processor()
    {
        this.cores = new Vector<Core>();
    }
    
    public void setProcessorModel(String m)
    {
        this.model = m;
    }
    
    public String getProcessorModel()
    {
        return this.model;
    }
    
    public void setSimulation(Simulator sim)
    {
        this.simulation = sim;
    }
    
    public Simulator getSimulation()
    {
        return this.simulation;
    }
    
    public void addCore(Core c)
    {
        this.cores.add(c);
    }
    
    public Vector<Core> getCores()
    {
        return this.cores;
    }
    
    public void run(int processedTime)
    {
        for(int i = 0; i < this.cores.size(); i++)
        {
            this.cores.get(i).operation(processedTime);
        }
    }
}
