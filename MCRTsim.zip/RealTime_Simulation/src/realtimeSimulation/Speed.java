/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package realtimeSimulation;

/**
 *
 * @author ShiuJia
 */
public class Speed
{
    private int frequency;
    private int power;
    private double normalization;
    
    public Speed()
    {
        
    }
    
    public void setFrequency(int f)
    {
        this.frequency = f;
    }
    
    public int getFrequency()
    {
        return this.frequency;
    }
    
    public void setPower(int p)
    {
        this.power = p;
    }
    
    public int getPower()
    {
        return this.power;
    }
    
    public void setNormalization(double n)
    {
        this.normalization = ((int)(Math.ceil(n * 100000))) / 100000.0;
    }
    
    public double getNormalization()
    {
        return this.normalization;
    }
}
