/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package realtimeSimulation;

import java.util.Vector;
import realtimeSimulation.schedulingAlgorithm.DynamicPrioritySchedulingAlgorithm;

/**
 *
 * @author ShiuJia
 */
public class Core
{
    private int ID;
    private Processor processor;
    private Vector<Speed> supportSpeed;
    private Speed currentSpeed;
    private Scheduler localScheduler;
    private Controller controller;
    private JobQueue localReadyQueue;
    private JobQueue localWaitQueue;
    private double currentTime;
    private Job workingJob, prevJob;
    private boolean resourceChange;
    private Vector<Result> record;
    private DynamicVoltageRegulator dynamicVoltageRegulator;
    private double powerConsumption;
    private boolean preemptible;
    
    public Core()
    {
        this.ID = 0;
        this.processor = new Processor();
        this.supportSpeed = new Vector<Speed>();
        this.currentSpeed = new Speed();
        this.localScheduler = new Scheduler();
        this.controller = new Controller();
        this.localReadyQueue = new JobQueue();
        this.localWaitQueue = new JobQueue();
        this.workingJob = null;
        this.prevJob = null;
        this.resourceChange = false;
        this.record = new Vector<Result>();
        this.dynamicVoltageRegulator = new DynamicVoltageRegulator();
        this.powerConsumption = 0.0;
        this.preemptible = true;
    }
    
    public void setID(int i)
    {
        this.ID = i;
    }
    
    public int getID()
    {
        return this.ID;
    }
    
    public void setProcessor(Processor p)
    {
        this.processor = p;
    }
    
    public Processor getProcessor()
    {
        return this.processor;
    }
    
    public void setSupportSpeed(Vector<Speed> s)
    {
        this.supportSpeed = s;
    }
    
    public Vector<Speed> getSupportSpeed()
    {
        return this.supportSpeed;
    }
    
    public void setCurrentSpeed(Speed s)
    {
        this.currentSpeed = s;
    }
    
    public Speed getCurrentSpeed()
    {
        return this.currentSpeed;
    }
    
    public void setLocalSchedulingAlgorithm(DynamicPrioritySchedulingAlgorithm algorithm)
    {
        this.localScheduler.setSchedAlgorithm(algorithm);
    }
    
    public Scheduler getLocalScheduler()
    {
        return this.localScheduler;
    }
    
    public void setController(Controller c)
    {
        this.controller = c;
    }
    
    public void setDynamicVoltageRegulator(DynamicVoltageRegulator v)
    {
        this.dynamicVoltageRegulator = v;
        this.dynamicVoltageRegulator.setCore(this);
    }
    
    public void setLocalReadyQueue(JobQueue jq)
    {
        this.localReadyQueue = jq;
    }
    
    public JobQueue getLocalReadyQueue()
    {
        return this.localReadyQueue;
    }
    
    public Job getWorkingJob()
    {
        return this.workingJob;
    }
    
    public void operation(int processedTime)
    {
        double targetTime = this.currentTime + processedTime;
        if(this.preemptible)
        {
            this.workingJob = this.localReadyQueue.peek();
        }
        while(targetTime > this.currentTime)
        {
            if(this.workingJob != null)
            {
                //System.out.println("TTT" + this.workingJob.getProgressAmount() + "/" + this.currentTime);
                if(this.controller.lockControl(this.workingJob))
                {
                    this.dynamicVoltageRegulator.scaling();
                    
                    if(this.resourceChange == true)
                    {
                        this.outPrint();
                        this.resourceChange = false;
                    }
                    
                    this.processing(targetTime - this.currentTime);
                    
                    this.controller.unlockControl(this.workingJob);
                    if(this.workingJob.getProgressAmount() == this.workingJob.getTargetAmount())
                    {
                        while(this.workingJob.getLockedResource().size() > 0 && this.workingJob.getLockedResource().peek() != null)
                        {
                            this.workingJob.unLock(this.workingJob.getLockedResource().pop());
                        }
                        this.localReadyQueue.remove(this.workingJob);
                        this.workingJob = this.localReadyQueue.peek();
                    }
                }
                else
                {
                    this.workingJob = this.localReadyQueue.peek();
                }
            }
            else
            {
                if(this.prevJob != null)
                {
                    System.out.println(this.currentTime / 100000 + ":I:" + this.currentSpeed.getFrequency());
                    if(this.record.size() > 0)
                    {
                        this.record.get(this.record.size() - 1).setEndTime(this.currentTime/100000);
                    }
                    this.record.add(new Result(this.currentTime / 100000, Status.IDLE, this.currentSpeed, null));
                    this.prevJob = null;
                }
                this.currentTime += ((int)(Math.ceil((targetTime - this.currentTime) * 100000))) / 100000.0;
            }
        }
        
    }
    
     private void processing(double processingTime)
    {
        if(this.prevJob != this.workingJob)
        {
            this.outPrint();
        }

        if((this.workingJob.getTargetAmount() - this.workingJob.getProgressAmount()) >= processingTime * ((double)this.currentSpeed.getFrequency() / this.workingJob.getTask().getMaxProcessingSpeed()))
        {
            this.currentTime += ((int)(Math.ceil(processingTime)));
            //System.out.println("A = " + this.currentTime);
            this.powerConsumption += processingTime * this.currentSpeed.getPower();
            this.workingJob.processed((processingTime * ((double)this.currentSpeed.getFrequency() / this.workingJob.getTask().getMaxProcessingSpeed())));
            //System.out.println(this.workingJob.getProgressAmount() + "/" + this.workingJob.getTargetAmount() + "=" + this.currentTime);
        }
        else
        {
            this.currentTime += ((int)(Math.ceil(((this.workingJob.getTargetAmount() - this.workingJob.getProgressAmount()) / ((double)this.currentSpeed.getFrequency() / this.workingJob.getTask().getMaxProcessingSpeed())))));
            //System.out.println("B = " + this.currentTime);
            this.powerConsumption += ((this.workingJob.getTargetAmount() - this.workingJob.getProgressAmount()) / ((double)this.currentSpeed.getFrequency() / this.workingJob.getTask().getMaxProcessingSpeed())) * this.currentSpeed.getPower();
            this.workingJob.processed(this.workingJob.getTargetAmount() - this.workingJob.getProgressAmount());
            //System.out.println(this.workingJob.getProgressAmount() + "/" + this.workingJob.getTargetAmount() + "=" + this.currentTime);
        }
    }
    
    public void outPrint()
    {
        boolean isPrint = false;
        System.out.printf(this.currentTime / 100000 + ":E:" + this.currentSpeed.getFrequency() + ":" + this.workingJob.getTask().getID() + "|");
        for(int i = 0; i < this.workingJob.getLockedResource().size(); i++)
        {
            if(isPrint == true)
            {
                System.out.printf(",");
            }
            System.out.printf(""+this.workingJob.getLockedResource().get(i).getResource().getID());
            isPrint = true;
        }
        if(isPrint == false)
        {
            System.out.println("0");
        }
        else
        {
            System.out.println();
        }
        if(this.record.size() > 0)
        {
            this.record.get(this.record.size() - 1).setEndTime(this.currentTime/100000);
        }
        this.record.add(new Result(this.currentTime / 100000, Status.EXECUTION, this.currentSpeed, this.workingJob));
        //System.out.println("="+this.record.get(this.record.size()-1).getJob().getLockedResource().size());
        this.prevJob = this.workingJob;
    }
    
    public void setResourceChange()
    {
        this.resourceChange = true;
    }
    
    public Vector<Result> getRecord()
    {
        return this.record;
    }
    
    public double getPowerConsumption()
    {
        return this.powerConsumption;
    }
    
    public void setPreemptible(boolean b)
    {
        this.preemptible = b;
    }
    
    public boolean getPreemptible()
    {
        return this.preemptible;
    }
}
