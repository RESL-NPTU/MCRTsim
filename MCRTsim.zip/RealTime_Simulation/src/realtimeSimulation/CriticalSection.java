/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package realtimeSimulation;

/**
 *
 * @author ShiuJia
 */
public class CriticalSection implements Comparable
{
    private Resource resource; //所使用的資源
    private double relativeStartTime; //開始使用資源的相對時間
    private double relativeEndTime; //結束使用資源的相對時間
    
    public CriticalSection()
    {
        
    }
    
    public void setResource(Resource r)
    {
        this.resource = r;
    }
    
    public Resource getResource()
    {
        return this.resource;
    }
    
    public void setStartTime(double st)
    {
        this.relativeStartTime = st;
    }
    
    public double getStartTime()
    {
        return this.relativeStartTime;
    }
    
    public void setEndTime(double et)
    {
        this.relativeEndTime = et;
    }
    
    public double getEndTime()
    {
        return this.relativeEndTime;
    }
    
    @Override
    public int compareTo(Object o)
    {
        CriticalSection cs = (CriticalSection)o;
        if(this.relativeStartTime < cs.relativeStartTime)
        {
            return -1;
        }
        else if(this.relativeStartTime > cs.relativeStartTime)
        {
            return 1;
        }
        else if(this.relativeStartTime == cs.relativeStartTime)
        {
            if(this.relativeEndTime < cs.relativeEndTime)
            {
                return 1;
            }
            else if(this.relativeEndTime >= cs.relativeEndTime)
            {
                return -1;
            }
        }    
        return 0;
    }
}