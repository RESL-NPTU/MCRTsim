/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package realtimeSimulation;

import java.util.Vector;

/**
 *
 * @author ShiuJia
 */
public class Resource
{
    private int ID; //代碼
    private Job lockedBy; //鎖定使用權的Job
    private TaskSet accessSet; //所有將使用此資源的工作
    private JobQueue waitQueue; //被lockedBy所阻擋的Job
    private Priority priorityCeiling;
    private Priority preemptionLevel;
    
    public Resource()
    {
        this.lockedBy = null;
        this.accessSet = new TaskSet();
        this.waitQueue = new JobQueue();
        this.priorityCeiling = new Priority();
        this.preemptionLevel = new Priority();
    }
    
    public void setID(int i)
    {
        this.ID = i;
    }
    
    public int getID()
    {
        return this.ID;
    }
    
    public Job whoLocked()
    {
        return this.lockedBy;
    }
    
    public void setLockedBy(Job j)
    {
        this.lockedBy = j;
    }
    
    public TaskSet getAccessSet()
    {
        return this.accessSet;
    }
    
    public JobQueue getWaitQueue()
    {
        return this.waitQueue;
    }
    
    public void blocked(Job j)
    {
        this.getWaitQueue().add(j);
        j.getLocationCore().getLocalReadyQueue().remove(j);
    }
    
    public void setPriorityCeiling(Priority p)
    {
        this.priorityCeiling = p;
    }
    
    public Priority getPriorityCeiling()
    {
        return this.priorityCeiling;
    }
    
    public void setPreemptionLevelCeiling(Priority p)
    {
        this.preemptionLevel = p;
    }
    
    public Priority getPreemptionLevelCeiling()
    {
        return this.preemptionLevel;
    }
    
    public boolean isPriorityHigher(Priority p)
    {
        if(this.priorityCeiling.getValue() > p.getValue())
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    public boolean isPreemptionLevelHigher(Priority p)
    {
        if(this.preemptionLevel.getValue() > p.getValue())
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}
