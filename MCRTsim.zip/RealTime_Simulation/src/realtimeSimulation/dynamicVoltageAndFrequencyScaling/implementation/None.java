/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package realtimeSimulation.dynamicVoltageAndFrequencyScaling.implementation;

import realtimeSimulation.dynamicVoltageAndFrequencyScaling.DynamicVoltageAndFrequencyScalingMethod;

/**
 *
 * @author ShiuJia
 */
public class None extends DynamicVoltageAndFrequencyScalingMethod
{
    public None()
    {
        this.setName("None");
    }
    
    @Override
    public void scalingVoltage()
    {
        this.getVoltageScaling().getCore().setCurrentSpeed(this.getVoltageScaling().getCore().getSupportSpeed().get(this.getVoltageScaling().getCore().getSupportSpeed().size() - 4));
    }
    
}
