/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rtsUI.resultViewer;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Enumeration;
import java.util.Scanner;
import java.util.ArrayList;
import javax.swing.JLabel;
import javax.swing.JPanel;
import rtsUI.InfoWin;
/**
 *
 * @author YC
 */
public class Resources extends JPanel{
        TaskExecution parent;
        String str;
        public Resources(TaskExecution tt,String s){
                super();
                parent = tt;
                str=s;
        }
        
}
