/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rtsUI;

import java.awt.Color;
import java.awt.Menu;
import java.awt.MenuBar;
import java.io.File;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import rtsUI.Attributes;

/**
 *
 * @author ShiuJia
 */
public class UserInterface
{
    private JFrame frame;
    private SimulationViewer simView;
    private InfoWin result;
    private JSplitPane bottomSplitpane ;
    private Attributes atb; 
    
    public UserInterface()
    {
        this.initialize();
        this.frame.setVisible(true);
    }
    
    private void initialize()
    {
        this.frame = new JFrame("MCRTSim v0.1");
        this.frame.setBounds(100, 100, 1000, 600);
        this.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
       // this.frame.setTitle("MCRTSim v0.1");
        
        JSplitPane splitPane = new JSplitPane();
        this.frame.getContentPane().add(splitPane);
        splitPane.setOrientation(0);
        splitPane.setContinuousLayout(false);
        splitPane.setDividerLocation(180);
        simView = new SimulationViewer(this);
        splitPane.setTopComponent(simView);
        result = new InfoWin(this);
        bottomSplitpane = new JSplitPane();
        bottomSplitpane.setOrientation(1);
        bottomSplitpane.setContinuousLayout(false);
       
        bottomSplitpane.setDividerLocation(this.frame.getWidth()-180);
        System.out.println(this.frame.getWidth());
        splitPane.setBottomComponent(bottomSplitpane);
        bottomSplitpane.setTopComponent(result);
        
        atb=new Attributes(this);
        bottomSplitpane.setBottomComponent(atb);
        

       
                
    }
    public SimulationViewer getSimulationViewer()
    {
        return this.simView;
    }
    
    
    public JFrame getFrame()
    {
        return this.frame;
    }
    
    public Attributes getAttributes()
    {
        return this.atb;
    }
    
    public InfoWin getInfoWin()
    {
        return this.result;
    }
    
    public JSplitPane getBottomSplitpane()
    {
        return this.bottomSplitpane;
    }
}