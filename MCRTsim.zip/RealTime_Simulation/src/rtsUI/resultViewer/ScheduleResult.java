/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rtsUI.resultViewer;

import rtsUI.InfoWin;
import java.awt.Color;
import java.util.*;
import realtimeSimulation.Core;
import realtimeSimulation.DataReader;
import realtimeSimulation.Result;
import realtimeSimulation.Status;
/**
 *
 * @author ShiuJia
 */
public class ScheduleResult 
{
        public int finalTime;
	public int numTasks;
	public int numResources;
	Dictionary<String, TaskTimeLine> tasks;
	public int baseunit=40;
	InfoWin parent;
	private Result curRecord;
        private AtbSet atbSet;
        int accuracy = 100;
        DataReader dr;
        
        
	public ScheduleResult(InfoWin p) 
	{
                parent = p;
                atbSet = new AtbSet();
                
                
                dr = parent.parent.getSimulationViewer().getDataReader();
                Vector<Core> core = dr.getDataSetting().getProcessor().getCores();
                Vector<Result> record = core.get(0).getRecord();
                
                finalTime =Double.valueOf(record.get(record.size()-1).getEndTime()).intValue();
                
                for (int i=0;i<record.size();i++)
                {
                    for(int j=Double.valueOf(record.get(i).getStartTime()*accuracy).intValue();j<Double.valueOf(record.get(i).getEndTime()*accuracy).intValue();j++)
                    {
                        this.atbSet.add(record.get(i));
                    }
                    
                    if(i==record.size()-1)              //----add lastrecord
                        this.atbSet.add(record.get(i));
                }
      
                numTasks = dr.getDataSetting().getTaskSet().size();
                numResources = dr.getDataSetting().getResourceSet().size();
                //System.out.println("numTasks=" + numTasks);
                //System.out.println("numResources=" + numResources);
		
                tasks = new Hashtable<String, TaskTimeLine>();
		
                for(int i=0;i<numTasks;i++)
		{
                    String id = String.valueOf(i+1);
               	    tasks.put(id , new TaskTimeLine(this, i, id));
		}
                
                TaskTimeLine ttl;
                //System.out.println("gapTime.size()=" + gapTime.size());
                for(int i=0;i<record.size();i++)
		{  
                    curRecord = record.get(i);
                    System.out.println(""+curRecord.getEndTime());
                    if(curRecord.getStatus() == Status.EXECUTION)
                    {
                        //ttl = tasks.get(String.valueOf(curRecord.getJob().getID()));
                        ttl = tasks.get(String.valueOf(this.curRecord.getJob().getTask().getID()));
                        
                        ArrayList<String> resources = new ArrayList<String>();
			
                        System.out.println("LockedResource().size()="+this.curRecord.getLockedResource().size());
                        for(int j=0;j<this.curRecord.getLockedResource().size();j++)
                        {
                            resources.add(String.valueOf(this.curRecord.getLockedResource().get(j).getResource().getID()));
                        }
                         ttl.addExecution(curRecord.getStartTime(),curRecord.getEndTime(),"E",curRecord.getSpeed().getFrequency(),resources);
                          
                        resources=null;
                        
                        
                    }
                    else if(curRecord.getStatus() == Status.IDLE)
                    { 
                        ttl = tasks.get("1");
                        
                        ttl.addExecution(curRecord.getStartTime(),curRecord.getEndTime(),"I",curRecord.getSpeed().getFrequency());//worng?execution
                        
                    }
                    else if(curRecord.getStatus() == Status.WRONG)
                    {
                        ttl = tasks.get(String.valueOf(this.curRecord.getJob().getTask().getID()));
                        
                        ttl.addExecution(curRecord.getStartTime(),curRecord.getEndTime(),"X",0);//worng?execution
                    }
                
		}
                
		//scanner.close();
		
	}
        
        public AtbSet getAtbSet()
        {
            return this.atbSet;
        }
	
}

