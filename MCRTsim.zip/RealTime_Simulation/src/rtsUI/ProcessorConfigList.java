/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rtsUI;

import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import realtimeSimulation.Processor;

/**
 *
 * @author ShiuJia
 */
public class ProcessorConfigList extends JPanel
{
    private int ID;
    private JComboBox<String> schedulingComboBox;
    private JComboBox<String> controlComboBox;
    private JTextField processorSpeedTextField;
    
    public ProcessorConfigList(int i)
    {
        super();
        this.ID = i;
        this.initialize();
        
        this.schedulingComboBox.addItemListener
        (
            new ItemListener()
            {
                public void itemStateChanged(ItemEvent e)
                {
                    if(e.getStateChange() == e.SELECTED)
                    {
                        if(schedulingComboBox.getSelectedItem().toString() == "RMS")
                        {
                            controlComboBox.removeAllItems();
                            controlComboBox.addItem("PCP");
                            controlComboBox.addItem("SRP");
                            controlComboBox.addItem("NPCS");
                        }
                        else if(schedulingComboBox.getSelectedItem().toString() == "EDF")
                        {
                            controlComboBox.removeAllItems();
                            controlComboBox.addItem("SRP");
                            controlComboBox.addItem("NPCS");
                        }
                    }
                }
            }
        );
    }
    
    private void initialize()
    {
        JLabel label1 = new JLabel("ID: " + this.ID);
        this.add(label1);
        
        JLabel label2 = new JLabel("Scheduling: ");
        this.add(label2);
        this.schedulingComboBox = new JComboBox<String>();
        this.add(this.schedulingComboBox);
        this.schedulingComboBox.addItem("RMS");
        this.schedulingComboBox.addItem("EDF");
        
        JLabel label3 = new JLabel("ControlMethod: ");
        this.add(label3);
        this.controlComboBox = new JComboBox<String>();
        this.add(this.controlComboBox);
        this.controlComboBox.addItem("PCP");
        this.controlComboBox.addItem("SRP");
        
        JLabel label4 = new JLabel("ProcessorSpeed: ");
        this.add(label4);
        this.processorSpeedTextField = new JTextField("300", 5);
        this.add(this.processorSpeedTextField);
    }
    
//    public Processor createProcessor()
//    {
//        return new Processor(this.ID, Integer.valueOf(this.processorSpeedTextField.getText()));
//    }
}
