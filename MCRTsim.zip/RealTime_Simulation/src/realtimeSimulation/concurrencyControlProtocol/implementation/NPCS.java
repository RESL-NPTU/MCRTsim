/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package realtimeSimulation.concurrencyControlProtocol.implementation;

import realtimeSimulation.Controller;
import realtimeSimulation.DataSetting;
import realtimeSimulation.Job;
import realtimeSimulation.Resource;
import realtimeSimulation.concurrencyControlProtocol.ConcurrencyControlProtocol;
import realtimeSimulation.concurrencyControlProtocol.ConcurrencyControlProtocol;

/**
 *
 * @author ShiuJia
 */
public class NPCS extends ConcurrencyControlProtocol
{
    public NPCS(DataSetting ds)
    {
        super(ds);
        this.setName("Non-Preemptible Critical Section");
    }

    @Override
    public Resource checkLock(Job j, Resource r)
    {
        if(r.whoLocked() == null) //檢查使用資源是否已被Lock：通過
        {
            j.getLocationCore().setPreemptible(false);
            return null;
        }
        else //檢查使用資源是否已被Lock：阻擋(不必要)
        {
            return r;
        }
    }
}
