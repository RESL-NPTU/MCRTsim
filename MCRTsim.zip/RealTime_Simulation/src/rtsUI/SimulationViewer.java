/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rtsUI;


import rtsUI.UserInterface;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FileDialog;
import java.awt.GridLayout;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JToolBar;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import org.dom4j.DocumentException;
import realtimeSimulation.Controller;
import realtimeSimulation.DataReader;
import realtimeSimulation.Processor;
import realtimeSimulation.Simulator;
import realtimeSimulation.Processor;
import realtimeSimulation.Core;
import realtimeSimulation.DataSetting;
import realtimeSimulation.Result;
import realtimeSimulation.Resource;
import realtimeSimulation.concurrencyControlProtocol.ConcurrencyControlProtocol;
import realtimeSimulation.dynamicVoltageAndFrequencyScaling.DynamicVoltageAndFrequencyScalingMethod;
import realtimeSimulation.schedulingAlgorithm.DynamicPrioritySchedulingAlgorithm;
import realtimeSimulation.schedulingAlgorithm.PriorityDrivenSchedulingAlgorithm;

/**
 *
 * @author ShiuJia
 */
public class SimulationViewer extends JPanel
{
    UserInterface parent;
    
    private JButton dataGeneratorBtn;
    private JButton readSourceFileBtn;
    private JTextField sourceTextField;
    private JButton readEnvironmentFileBtn;
    private JTextField environmentTextField;
    private JComboBox<String> schedulingComboBox;
    private JComboBox<String> controlComboBox;
    private JComboBox<String> energyComboBox;
    
    private ButtonGroup simTimeBG;
    private JRadioButton lcmRB, customRB;
    private JTextField simTimeField;
    
    private JButton startBtn;
    private JButton testBtn;
    private DataReader dr;
    
    public SimulationViewer(UserInterface ui)
    {
        super();
        this.parent = ui;
        this.setLayout(new GridLayout(0,1));
        this.initialize();
        
        this.dataGeneratorBtn.addMouseListener
        (
            new MouseAdapter()
            {
                public void mouseClicked(MouseEvent e)
                {
                    sourceTextField.setText("Use DataGenerator");
                }
            }
        );
        
        this.readSourceFileBtn.addMouseListener
        (
            new MouseAdapter()
            {
                public void mouseClicked(MouseEvent e)
                {
                    FileDialog fileDialog = new FileDialog(parent.getFrame(), "new", FileDialog.LOAD);
                    fileDialog.setVisible(true);
                    sourceTextField.setText(fileDialog.getDirectory() + fileDialog.getFile());
                }
            }
        );
        
        this.readEnvironmentFileBtn.addMouseListener
        (
            new MouseAdapter()
            {
                public void mouseClicked(MouseEvent e)
                {
                    FileDialog fileDialog = new FileDialog(parent.getFrame(), "new", FileDialog.LOAD);
                    fileDialog.setVisible(true);
                    environmentTextField.setText(fileDialog.getDirectory() + fileDialog.getFile());
                }
            }
        ); 
        
        this.testBtn.addMouseListener(new MouseAdapter(){
            public void mouseClicked(MouseEvent e)
            {    
            //System.out.println("123");
            Vector<Core> cr = SimulationViewer.this.dr.getDataSetting().getProcessor().getCores();
            System.out.println(cr.size());
            
            Vector<Result> rcd =cr.get(0).getRecord();
            System.out.println("rcd.size()="+rcd.size());
            System.out.println("Status="+rcd.get(0).getStatus());
            System.out.println("numResources=" + 1);
            System.out.println("lockedResources=" + dr.getDataSetting().getProcessor().getCores().get(0).getRecord().get(1).getJob().getLockedResource().size());
            
            }
        });
        
        this.lcmRB.addItemListener
        (
            new ItemListener()
            {
                @Override
                public void itemStateChanged(ItemEvent e)
                {
                    simTimeField.setEditable(false);
                }
            }
        );
        
        this.customRB.addItemListener
        (
            new ItemListener()
            {
                @Override
                public void itemStateChanged(ItemEvent e)
                {
                    simTimeField.setEditable(true);
                }
            }
        );
        
        this.startBtn.addMouseListener
        (new MouseAdapter()
            {
                public void mouseClicked(MouseEvent e)
                {
                    
                    try
                    {
                        dr = new DataReader();
                        
                        try
                        {
                            dr.read(sourceTextField.getText());
                            dr.read(environmentTextField.getText());
                        }
                        catch (IOException ex)
                        {
                            Logger.getLogger(SimulationViewer.class.getName()).log(Level.SEVERE, null, ex);
                        }
                        catch (DocumentException ex)
                        {
                            Logger.getLogger(SimulationViewer.class.getName()).log(Level.SEVERE, null, ex);
                        }
                        Simulator sim = new Simulator();
                        sim.setSimulationTime(getSimulationTime());
                        sim.loadDataSetting(dr.getDataSetting()); 
                        System.out.println("SimulationTime = " + sim.getSimulationTime());
                        sim.setSchedAlgorithm(getDynamicPrioritySchedulingAlgorithm());
                        System.out.println("SchedAlgorithm = " + sim.getScheduler().getSchedulingAlgorithm().getName());
                        sim.setCCProtocol(getConcurrencyControlProtocol());
                        System.out.println("CCProtocol = " + sim.getController().getCCProtocol().getName());
                        sim.setDVFSMethod(getDynamicVoltageScalingMethod());
                        System.out.println("DVFSMethod = " + sim.getDynamicVoltageRegulator().getDVFSMethod().getName());
                        sim.start();
                        
                    }
                    catch (ClassNotFoundException ex)
                    {
                        Logger.getLogger(SimulationViewer.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    catch (InstantiationException ex)
                    {
                        Logger.getLogger(SimulationViewer.class.getName()).log(Level.SEVERE, null, ex);
                    } 
                    catch (IllegalAccessException ex)
                    {
                        Logger.getLogger(SimulationViewer.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    catch (NoSuchMethodException ex)
                    {
                        Logger.getLogger(SimulationViewer.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    catch (IllegalArgumentException ex)
                    {
                        Logger.getLogger(SimulationViewer.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    catch (InvocationTargetException ex)
                    {
                        Logger.getLogger(SimulationViewer.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
        );
    }
    
    private void initialize()
    {
        JToolBar dataToolBar = new JToolBar();
        this.add(dataToolBar);
        JLabel dataLabel = new JLabel("Workload: ");
        dataToolBar.add(dataLabel);
        
        this.dataGeneratorBtn = new JButton("DataGenerator");
        dataToolBar.add(this.dataGeneratorBtn);
        this.readSourceFileBtn = new JButton("Open File...");
        dataToolBar.add(this.readSourceFileBtn);
        this.sourceTextField = new JTextField();
        dataToolBar.add(this.sourceTextField);
        
        JToolBar environmentToolBar = new JToolBar();
        this.add(environmentToolBar);
        JLabel environmentLabel = new JLabel("Environment: ");
        environmentToolBar.add(environmentLabel);
        this.readEnvironmentFileBtn = new JButton("Open File...");
        environmentToolBar.add(this.readEnvironmentFileBtn);
        this.environmentTextField = new JTextField();
        environmentToolBar.add(this.environmentTextField);
        
        JToolBar configToolBar = new JToolBar();
        this.add(configToolBar);
        
        JLabel energyLabel = new JLabel("DVFSMethod: ");
        configToolBar.add(energyLabel);
        this.energyComboBox = new JComboBox<String>();
        configToolBar.add(this.energyComboBox);
        Vector<String> fileName = new Vector<String>();
        fileName = this.getFolderFile("./src/realtimeSimulation/dynamicVoltageAndFrequencyScaling/implementation");
        for(int i = 0; i < fileName.size(); i++)
        {
            this.energyComboBox.addItem(fileName.get(i));
        }
        
        JLabel schedulerLabel = new JLabel("SchedAlgorithm: ");
        configToolBar.add(schedulerLabel);
        this.schedulingComboBox = new JComboBox<String>();
        configToolBar.add(this.schedulingComboBox);
        fileName = this.getFolderFile("./src/realtimeSimulation/schedulingAlgorithm/implementation");
        for(int i = 0; i < fileName.size(); i++)
        {
            this.schedulingComboBox.addItem(fileName.get(i));
        }
        
        JLabel controllerLabel = new JLabel("CCProtocol: ");
        configToolBar.add(controllerLabel);
        this.controlComboBox = new JComboBox<String>();
        configToolBar.add(this.controlComboBox);
        fileName = this.getFolderFile("./src/realtimeSimulation/concurrencyControlProtocol/implementation");
        for(int i = 0; i < fileName.size(); i++)
        {
            this.controlComboBox.addItem(fileName.get(i));
        }
        //-----
        JToolBar simTimeToolBar = new JToolBar();
        this.add(simTimeToolBar);
        JLabel simTimeLabel = new JLabel("SimulationTime: ");
        simTimeToolBar.add(simTimeLabel);
        this.lcmRB = new JRadioButton();
        this.lcmRB.setText("Lcm of Period for TaskSet");
        this.lcmRB.setSelected(true);
        this.customRB = new JRadioButton();
        this.customRB.setText("Custom Time");
        this.simTimeBG = new ButtonGroup();
        this.simTimeBG.add(this.lcmRB);
        this.simTimeBG.add(this.customRB);
        simTimeToolBar.add(this.lcmRB);
        simTimeToolBar.add(this.customRB);
        this.simTimeField = new JTextField();
        simTimeToolBar.add(this.simTimeField);
        this.simTimeField.setEditable(false);
        //-----
        JToolBar processorToolBar = new JToolBar();
        this.add(processorToolBar);
        
        this.startBtn = new JButton("Start");
        processorToolBar.add(this.startBtn);
        this.startBtn.setForeground(Color.red);
        
        this.testBtn = new JButton("test");
      //  processorToolBar.add(this.testBtn);
        this.testBtn.setForeground(Color.BLUE);
    }
    
    public DataReader getDataReader()
    {
        return this.dr;
    }
    
    public Vector<String> getFolderFile(String path)
    {
        Vector<String> fileName = new Vector<String>();
        File folder = new File(path);
        String[] list = folder.list();
        for(int i = 0; i < list.length; i++)
        {
            fileName.add(list[i].split("\\.")[0]);
        }
        return fileName;
    }
    
    public PriorityDrivenSchedulingAlgorithm getDynamicPrioritySchedulingAlgorithm() throws ClassNotFoundException, InstantiationException, IllegalAccessException
    {
        return (PriorityDrivenSchedulingAlgorithm)Class.forName("realtimeSimulation.schedulingAlgorithm.implementation." + this.schedulingComboBox.getSelectedItem().toString()).newInstance();                
    }
    
    public DynamicVoltageAndFrequencyScalingMethod getDynamicVoltageScalingMethod() throws ClassNotFoundException, InstantiationException, IllegalAccessException
    {
        return (DynamicVoltageAndFrequencyScalingMethod)Class.forName("realtimeSimulation.dynamicVoltageAndFrequencyScaling.implementation." + this.energyComboBox.getSelectedItem().toString()).newInstance();
    }
    
    public ConcurrencyControlProtocol getConcurrencyControlProtocol() throws ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchMethodException, IllegalArgumentException, InvocationTargetException
    {
        return (ConcurrencyControlProtocol)Class.forName("realtimeSimulation.concurrencyControlProtocol.implementation." + this.controlComboBox.getSelectedItem().toString()).getConstructor(DataSetting.class).newInstance(dr.getDataSetting());
    }
    
    public long getSimulationTime()
    {
        if(this.lcmRB.isSelected())
        {
            return this.dr.getDataSetting().getTaskSet().getLcmOfPeriodForTaskSet();
        }
        else if(this.customRB.isSelected())
        {
            return Integer.valueOf(this.simTimeField.getText().toString());
        }
        return 0;
    }
}
