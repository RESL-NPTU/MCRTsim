/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package realtimeSimulation.schedulingAlgorithm.implementation;

import java.util.Vector;
import realtimeSimulation.Job;
import realtimeSimulation.JobQueue;
import realtimeSimulation.Priority;
import realtimeSimulation.schedulingAlgorithm.DynamicPrioritySchedulingAlgorithm;
import realtimeSimulation.schedulingAlgorithm.PriorityDrivenSchedulingAlgorithm;

/**
 *
 * @author ShiuJia
 */
public class EDF extends DynamicPrioritySchedulingAlgorithm
{    
    public EDF()
    {
        this.setName("Earliest Deadline First Scheduling Algorithm");
    }
    
    @Override
    public void setPriority(Job j)
    {
        j.setCurrentPriority(new Priority(j.getAbsoluteDeadline()));
        
        //jq = newJq;
        //System.out.println("ETTETTETE3=" + jq.size());
//        Vector<Job> jv = new Vector<Job>();
//        Job job = new Job();
//        while((job = jq.poll()) != null)
//        {
//            jv.add(job);
//        }
//        
//        Vector<Integer> in = new Vector<Integer>();
//        for(int i = 0; i < jv.size(); i++)
//        {
//            in.add(0);
//        }
//        for(int i = 0; i < jv.size() - 1; i++)
//        {
//            for(int j = i + 1; j < jv.size(); j++)
//            {
//                if(jv.get(i).getAbsoluteDeadline() < jv.get(j).getAbsoluteDeadline())
//                {
//                    in.set(i, in.get(i) - 1);
//                }
//                else
//                {
//                    in.set(j, in.get(j) - 1);
//                }
//            }
//        }
//        for(int i = 0; i < jv.size(); i++)
//        {
//            jv.get(i).setCurrentPriority(new Priority(in.get(i) + jv.size()));
//            jq.offer(jv.get(i));
//            System.out.println("JobID("+jv.get(i).getID()+"), "+jv.get(i).getCurrentPriority().getValue());
//        }
    }
}
