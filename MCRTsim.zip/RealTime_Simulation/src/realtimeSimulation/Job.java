/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package realtimeSimulation;

import java.util.PriorityQueue;
import java.util.Stack;
import java.util.Vector;

/**
 *
 * @author ShiuJia
 */
public class Job implements Comparable
{
    private int ID; //代碼，J{task.ID, ID}
    private Task task; //所屬何Task
    private int releaseTime; // 被產生之時間
    private int absoluteDeadline; // 絕對截止時間
    private double progressAmount; //工作進度量
    private double targetAmount; //目標工作量
    private Priority originalPriority; //最初優先權值
    private Priority currentPriority; //當前優先權值
    private PriorityQueue<CriticalSection> lockResource; //尚未Lock之所需資源
    private Core locationCore;
    private Stack<LockInfo> lockedResource; //已Lock之所需資源
    private Priority preemptionLevel;
    
    public Job()
    {
        this.lockResource = new PriorityQueue<CriticalSection>();
        this.lockedResource = new Stack<LockInfo>();
        this.originalPriority = new Priority();
        this.currentPriority = new Priority();
        this.preemptionLevel = new Priority();
    }
    
    public void setID(int i)
    {
        this.ID = i;
    }
    
    public int getID()
    {
        return this.ID;
    }
    
    public void setTask(Task t)
    {
        this.task = t;
    }
    
    public Task getTask()
    {
        return this.task;
    }
    
    public void setReleaseTime(int rt)
    {
        this.releaseTime = rt;
    }
    
    public int getReleaseTime()
    {
        return this.releaseTime;
    }
    
    public void setAbsoluteDeadline(int d)
    {
        this.absoluteDeadline = d;
    }
    
    public int getAbsoluteDeadline()
    {
        return this.absoluteDeadline;
    }
    
    public void setProgressAmount(double p)
    {
        this.progressAmount = p;
    }
    
    public double getProgressAmount()
    {
        return this.progressAmount;
    }
    
    public void setTargetAmount(double t)
    {
        this.targetAmount = t;
    }
    
    public double getTargetAmount()
    {
        return this.targetAmount;
    }

    public void setOriginalPriority(Priority p)
    {
        this.originalPriority = p;
    }
    
    public Priority getOriginalPriority()
    {
        return this.originalPriority;
    }
    
    public void setCurrentPriority(Priority p)
    {
        this.currentPriority = p;
        if(this.locationCore != null)
        {
            this.locationCore.getLocalReadyQueue().remove(this);
            this.locationCore.getLocalReadyQueue().add(this);
        }
    }
    
    public void inheritCurrentPriorityBy(Job j)
    {
        this.setCurrentPriority(j.getCurrentPriority());
        this.locationCore.getLocalReadyQueue().remove(this);
        this.locationCore.getLocalReadyQueue().add(this);
    }
    
    public Priority getCurrentPriority()
    {
        return this.currentPriority;
    }
    
    public void setCriticalSectionSet()
    {
        for(int i = 0; i < this.getTask().getCriticalSectionSet().size(); i++)
        {
            CriticalSection newCriticalSection = new CriticalSection();
            newCriticalSection.setResource(this.getTask().getCriticalSectionSet().get(i).getResource());
            newCriticalSection.setStartTime(this.getTask().getCriticalSectionSet().get(i).getStartTime());
            newCriticalSection.setEndTime(this.getTask().getCriticalSectionSet().get(i).getEndTime());
            this.lockResource.offer(newCriticalSection);
            //System.out.println("css= " + css.get(css.size() - 1).getResource().getID() + "," + css.get(css.size() - 1).getStartTime() + "," + css.get(css.size() - 1).getEndTime());
        }
    }
    
    public CriticalSectionSet getCriticalSectionSet()
    {
        return this.getTask().getCriticalSectionSet();
    }
    
    public void setLocationCore(Core c)
    {
        this.locationCore = c;
    }
    
    public Core getLocationCore()
    {
        return this.locationCore;
    }
    
    public PriorityQueue<CriticalSection> getLockResource()
    {
        return this.lockResource;
    }
    
    public Stack<LockInfo> getLockedResource()
    {
        return this.lockedResource;
    }
    
    public void processed(double processedTime)
    {
        this.progressAmount += processedTime;
    }
    
    public void lock(CriticalSection cs)
    {
        cs.getResource().setLockedBy(this);
        this.lockedResource.push(new LockInfo(cs.getResource(), cs.getEndTime(), this.getCurrentPriority()));
    }
    
    public void unLock(LockInfo l)
    {
        l.getResource().setLockedBy(null);
        Job j = new Job();
        while((j = l.getResource().getWaitQueue().poll()) != null) //清空Resource.WaitQueue
        {
            j.getLocationCore().getLocalReadyQueue().offer(j);
        }
        this.currentPriority = l.getPriority();
    }

    @Override
    public int compareTo(Object o)
    {
        Job j = (Job)o;
        if(this.currentPriority.getValue() > j.currentPriority.getValue())
        {
            return -1;
        }
        else if(this.currentPriority.getValue() < j.currentPriority.getValue())
        {
            return 1;
        }
        return 0;
    }
    
    public boolean isPriorityHigher(Priority p)
    {
        if(this.currentPriority.getValue() > p.getValue())
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    public boolean isPreemptionLevelHigher(Priority p)
    {
        if(this.preemptionLevel.getValue() > p.getValue())
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}