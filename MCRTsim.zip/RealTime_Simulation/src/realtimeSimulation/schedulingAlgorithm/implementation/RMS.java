/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package realtimeSimulation.schedulingAlgorithm.implementation;

import java.util.Vector;
import realtimeSimulation.Job;
import realtimeSimulation.Priority;
import realtimeSimulation.Task;
import realtimeSimulation.TaskSet;
import realtimeSimulation.schedulingAlgorithm.FixedPrioritySchedulingAlgorithm;
import realtimeSimulation.schedulingAlgorithm.PriorityDrivenSchedulingAlgorithm;

/**
 *
 * @author ShiuJia
 */
public class RMS extends FixedPrioritySchedulingAlgorithm
{
    public RMS()
    {
        this.setName("Rate Monotonic Scheduling Algorithm");
    }

    @Override
    public void setPriority(TaskSet ts)
    {
        TaskSet temp = new TaskSet();
        temp.add(ts.get(0));
        for(int i = 1; i < ts.size(); i++)
        {
            int x = -1;
            for(int j = 0; j < temp.size(); j++)
            {
                if(ts.get(i).getPeriod() > temp.get(j).getPeriod())
                {
                    x = j;
                }
            }
            temp.add(x + 1, ts.get(i));

        }
        
        for(int i = 0; i < temp.size(); i++)
        {
            ts.get(temp.get(i).getID() - 1).setPriority(new Priority(i + 1));
        }
        
        

//        
//        Vector<Integer> in = new Vector<Integer>();
//        for(int i = 0; i < ts.size(); i++)
//        {
//            in.add(0);
//        }
//        for(int i = 0; i < ts.size() - 1; i++)
//        {
//            for(int j = i + 1; j < ts.size(); j++)
//            {
//                if(ts.get(i).getPeriod() < ts.get(j).getPeriod())
//                {
//                    in.set(i, in.get(i) - 1);
//                }
//                else
//                {
//                    in.set(j, in.get(j) - 1);
//                }
//            }
//        }
//        for(int i = 0; i < ts.size(); i++)
//        {
//            ts.get(i).setPriority(new Priority(in.get(i) + ts.size()));
//        }
        
        
        //t.setPriority(new Priority(t.getPeriod()));
    }
}
