/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package realtimeSimulation;

/**
 *
 * @author ShiuJia
 */
public class Event //助於計算排程速度？
{
    private int time;
    private Status status;
    private Job job;
    
    public Event(int t, Status s)
    {
        this.time = t;
        this.status = s;
        //this.job = j;
    }
    
    public int getTime()
    {
        return this.time;
    }
    
    public Status getStatus()
    {
        return this.status;
    }
    
    public Job getJob()
    {
        return this.job;
    }
}
