/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rtsUI.resultViewer;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.awt.image.BufferedImage;
import java.util.Enumeration;
import java.util.ArrayList;
import java.util.Vector;
import javafx.scene.image.Image;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.ToolTipManager;
import rtsUI.InfoWin;
/**
 *
 * @author ShiuJia
 */

public class ResultViewer extends JPanel
{
	public ScheduleResult parent;
        private int mouseX;
        public MouseStatus mouseStatus;
        private Double curTime;
        private JComboBox<Double> timeLineSet;
	private Vector<MouseTimeLine> mouseTimeLine;
        Color[] resourceColor;
        int numtest = 0;
        /**
	 * Create the panel.
	 */
	public ResultViewer(ScheduleResult sr) {
		super();
                this.mouseStatus = new MouseStatus();
                this.mouseTimeLine = new Vector<>();
                this.parent = sr;
		this.setLayout(null);
		this.setBackground(Color.white);
                this.timeLineSet = this.parent.parent.parent.getAttributes().getTimeLineSet();
                ToolTipManager.sharedInstance().setDismissDelay(Integer.MAX_VALUE);
                
                
                resourceColor = new Color[]
                {
                Color.getHSBColor((float) 0.1, 1, 1),Color.getHSBColor((float) 0.2, 1, 1),
                Color.getHSBColor((float) 0.3, 1, 1),Color.getHSBColor((float) 0.45,(float) 0.2, 1),
                Color.getHSBColor((float) 0.5, 1, 1),Color.getHSBColor((float) 0.58, 1, 1),
                Color.getHSBColor((float) 0.7, 1, 1),Color.getHSBColor((float) 0.8, 1, 1),
                Color.getHSBColor((float) 0.15, 1, 1),Color.getHSBColor((float) 1, 1, 1),
                
                Color.getHSBColor((float) 0.1, (float)0.5, (float)0.8),Color.getHSBColor((float) 0.2, (float)0.5, (float)0.8),
                Color.getHSBColor((float) 0.3, (float)0.5, (float)0.8),Color.getHSBColor((float) 0.45, (float)0.5, (float)0.8),
                Color.getHSBColor((float) 0.5, (float)0, (float)0.8),Color.getHSBColor((float) 0.6, (float)0.3, (float)1),
                Color.getHSBColor((float) 0.7, (float)0.2, (float)0.8),Color.getHSBColor((float) 0.17, (float)0.5, (float)1),
                Color.getHSBColor((float) 0.85, (float)0.3, (float)0.9),Color.getHSBColor((float) 1, (float)0.8, (float)0.6)
                };
                
                Enumeration<String> keys= parent.tasks.keys();
                
                for(int i=parent.tasks.size()-1;i>=0;i--)
		{
                    TaskTimeLine task = parent.tasks.get(keys.nextElement());
                    task.drawResources(this, resourceColor);
                }
                
                
                ResultViewer.this.parent.parent.getRVscrollPane().getHorizontalScrollBar().addAdjustmentListener(new AdjustmentListener(){
                    public void adjustmentValueChanged(AdjustmentEvent e) {
                /* if(e.getValueIsAdjusting()){
                    System.out.print(e.getValue());
                }*/
                       // ResultViewer.this.repaint(Integer.valueOf(ResultViewer.this.parent.parent.getRVscrollPane().getWidth()).longValue());
                    ResultViewer.this.repaint();
                    //System.out.println("1111");
                    }
                });
                
                ResultViewer.this.parent.parent.getRVscrollPane().getVerticalScrollBar().addAdjustmentListener(new AdjustmentListener(){
                    public void adjustmentValueChanged(AdjustmentEvent e) {
                /* if(e.getValueIsAdjusting()){
                    System.out.print(e.getValue());
                }*/
                       // ResultViewer.this.repaint(Integer.valueOf(ResultViewer.this.parent.parent.getRVscrollPane().getWidth()).longValue());
                    ResultViewer.this.repaint();
                    //System.out.println("2222");
                    }
                });
                
                this.addMouseMotionListener(new MouseAdapter(){
                        public void mouseMoved(MouseEvent e)
                        {
                            
                            mouseX=e.getX();
                            if(mouseX<100)
                            {
                                mouseX=100;
                            }
                           
                            if(mouseX>ResultViewer.this.parent.finalTime *ResultViewer.this.parent.baseunit+100)
                            {
                                mouseX=ResultViewer.this.parent.finalTime *ResultViewer.this.parent.baseunit+100;
                            }
                            
                            
                            
                            ResultViewer.this.curTime = (double)(mouseX-100)/sr.baseunit;
                            
                            ResultViewer.this.parent.parent.timeMessage.setText("Time:" + curTime);
                            
                            ResultViewer.this.parent.parent.parent.getAttributes().
                                    setAtbText(ResultViewer.this.parent.getAtbSet().
                                            get(Double.valueOf(ResultViewer.this.curTime * parent.accuracy).intValue()));
                            
                            if(ResultViewer.this.mouseStatus.getMouseStatus()==ViewerStatus.EXECUTION)
                            {
                            //   ResultViewer.this.repaint(e.getX()-5, 0, 10, ResultViewer.this.getHeight());
                                 ResultViewer.this.repaint();
                                //ResultViewer.this.updateUI();
                            }
                        }
                });
                
                this.addMouseListener(new MouseAdapter(){
                        public void mouseClicked(MouseEvent e)
                        {
                            if(ResultViewer.this.mouseStatus.getMouseStatus()==ViewerStatus.EXECUTION)
                            {
                                MouseTimeLine mtl = new MouseTimeLine(ResultViewer.this, ResultViewer.this.curTime);
                                ResultViewer.this.mouseTimeLine.add(mtl);
                                ResultViewer.this.add(mtl);
                                ResultViewer.this.timeLineSet.addItem(mtl.getCurTime());
                                ResultViewer.this.timeLineSet.setSelectedIndex(ResultViewer.this.timeLineSet.getItemCount()-1);
                                
                                /*
                                ResultViewer.this.parent.parent.getRVscrollPane().getHorizontalScrollBar().setValue(
                                        e.getX()-(ResultViewer.this.parent.parent.getRVscrollPane().getWidth()/2));
                                */
                               
                                
                                //System.out.println(""+ ResultViewer.this.getWidth() + "," + ResultViewer.this.parent.parent.getRVscrollPane().getWidth());
                                
                                //System.out.println(""+ e.getX() + ",mouseTimeLine.size()=" + ResultViewer.this.mouseTimeLine.size());
                                
                                repaint();
                            }
                        }
                });
                
                
	}
        

	public void paintComponent(Graphics g) {
                super.paintComponent(g);
                System.out.println(numtest++);
                System.out.println("" + this.getComponentZOrder(this));
                g.setPaintMode();
		g.setColor(Color.black);
				
		Enumeration<String> keys= parent.tasks.keys();
                
                for(int i=parent.tasks.size()-1;i>=0;i--)
		{
                    TaskTimeLine task = parent.tasks.get(keys.nextElement());
                    task.drawItself(g);
                    //task.drawResources(this,g, resourceColor);
                    task.reDrawResources(this, g, resourceColor);
                }
                
               
                //-----MouseTimeLine   v
                g.setColor(Color.red);
                for(MouseTimeLine i : this.mouseTimeLine)
                {
                    g.drawLine(i.getCurPoint(),30,i.getCurPoint(),this.getHeight()-20);
                    i.reSetItself();
                    //g.fillRect(Double.valueOf(i.getCurTime() * this.parent.baseunit).intValue()+100-5, 10, 10, 10);
                }
                //------MouseTimeLine   ^ 
                
                
                if(this.mouseStatus.getMouseStatus()==ViewerStatus.EXECUTION)
                {
                    g.drawLine(mouseX, 30, mouseX, this.getHeight()-20);
                }
                
                int x = this.parent.parent.getRVscrollPane().getHorizontalScrollBar().getValue();
                int y = this.parent.parent.getRVscrollPane().getVerticalScrollBar().getValue();
                
                g.setColor(Color.WHITE);
                g.fillRect(0,0+y,this.getWidth(),60);
                //-----MouseTimeLine   v
                g.setColor(Color.red);
                for(MouseTimeLine i : this.mouseTimeLine)
                {
                    g.fillRect(Double.valueOf(i.getCurTime() * this.parent.baseunit).intValue()+100-5, 10, 10, 10);
                }
                //------MouseTimeLine   ^
                g.setColor(Color.black);
                
                for(int i=1;i<=parent.numResources;i++)
		{
                        int resourcesWidth = this.parent.parent.parent.getBottomSplitpane().getTopComponent().getWidth() / parent.numResources;
                        g.setColor(resourceColor[i-1]);
			g.fillRect(x + resourcesWidth*(i-1), y+18, resourcesWidth, 13);
			g.setColor(this.reverseColor(resourceColor[i-1]));
                        g.drawString("R"+i,x + resourcesWidth*(i-1),y+30);
                        g.setColor(Color.black);
		}
                System.out.println("123123123123123123="+this.getComponentCount());
        }
        
        
        public void paint(Graphics g)
        {
            this.paintComponent(g);
            try { 
                Thread.sleep(0); // 避免Busy loop
            } 
            catch(InterruptedException e) { 
                    // 例外處理 
            }
        }
        
        public Double getCurTime()
        {
            return this.curTime;
        }
        
        
        public JComboBox<Double> getTimeLineSet()
        {
            return this.timeLineSet;
        }
        
        
        public Vector<MouseTimeLine> getMouseTimeLine()
        {
            return this.mouseTimeLine;
        }
        
        
        public Color reverseColor(Color color)
        {  
            int r = color.getRed();  
            int g = color.getGreen();  
            int b = color.getBlue();  
            int r_ = 255-r;  
            int g_ = 255-g;  
            int b_ = 255-b;  
            
            Color newColor = new Color(r_,g_,b_);  
            
            return newColor;  
        }
        
}
